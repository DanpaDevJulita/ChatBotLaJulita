# Panel de administración — La Julita

Panel web (Laravel + AdminLTE) para que el equipo de ventas administre el catálogo que usa el
chatbot de La Julita, sin tocar código ni la base de datos directamente.

**Para instalarlo, empieza por [INSTALL.md](./INSTALL.md).**

## Por qué existe

El bot (`bot-lajulita/`, Node.js + TypeScript) lee todo su catálogo de Supabase: planes,
políticas, domos, adicionales, recargos de niños/mascotas, FAQ, horarios y fechas bloqueadas
(ver `sql/schema.sql` en ese repo). Hasta ahora, cambiar cualquiera de esos datos significaba
entrar directo al SQL Editor de Supabase o usar el mini-panel que ya trae el bot
(`src/web/admin/`, protegido con una sola contraseña compartida). Este panel le da a cada
vendedor su propia cuenta, con permisos por módulo, y una interfaz completa en vez de
formularios sueltos.

## Arquitectura

```
┌─────────────────────┐        ┌──────────────────────────────┐
│   Bot (Node.js/TS)   │        │  Panel admin (Laravel/PHP)    │
│  le habla a Supabase │        │  le habla a la MISMA base     │
│  vía supabase-js     │        │  directo por Postgres         │
│  (API REST)          │        │  (Eloquent)                   │
└──────────┬───────────┘        └───────────────┬──────────────┘
           │                                     │
           └────────────► Supabase (Postgres) ◄──┘
                    planes, politicas, domos, clase_domo,
                    adicionales, tipo_adicional, recargos,
                    faq, configuracion, fechas_bloqueadas
                    (+ nuevas: promociones, bitacora_cambios,
                     roles, permisos, users — propias del panel)
```

Los dos sistemas leen y escriben las mismas tablas del catálogo. El panel agrega sus propias
tablas (usuarios del panel, roles, permisos, bitácora de cambios y promociones) que el bot no
usa.

## Módulos

| Menú | Qué administra | Tabla(s) |
|---|---|---|
| Planes | Nombre, descripción, los 3 precios (entre semana / fin de semana / puente), domos incluidos, video, activo/inactivo | `planes` |
| Domos y clases | Clases de domo y cada unidad física con su capacidad | `clase_domo`, `domos` |
| Adicionales | Tipos de adicional y cada adicional con su precio | `tipo_adicional`, `adicionales` |
| Niños y mascotas | Recargos por rango de edad y por mascota | `recargos` |
| Promociones | Descuentos por porcentaje o monto fijo, con código y vigencia (**nueva**, el bot aún no la usa) | `promociones` |
| Políticas | Términos, condiciones y demás textos que el bot manda tal cual | `politicas` |
| Preguntas frecuentes | FAQ del bot | `faq` |
| Horarios y fechas bloqueadas | Configuración clave/valor + fechas no disponibles | `configuracion`, `fechas_bloqueadas` |
| Usuarios | Cuentas del panel (vendedores, administradores) | `users` |
| Roles y permisos | Qué puede ver/crear/editar/eliminar cada rol, módulo por módulo | `roles`, `permisos`, `rol_permiso` |

## Seguridad y control de cambios

- Login propio por usuario (correo + contraseña), sin compartir una sola contraseña de equipo.
- Cada usuario tiene un rol; cada rol tiene permisos granulares por módulo (ver / crear /
  editar / eliminar). Se administran desde el mismo panel, en Roles y permisos.
- Cada creación, edición o borrado queda registrado en `bitacora_cambios` (quién, qué módulo,
  qué acción, valores antes/después) — visible en el Dashboard.
- Los "eliminar" respetan las mismas reglas que ya protegen la base (por ejemplo, no se puede
  borrar una clase de domo si algún domo la usa, ni un domo si algún plan lo incluye — son los
  mismos triggers de `sql/schema.sql` del bot).

## Punto delicado a vigilar

`planes.domos_id` es un arreglo de enteros (`int[]`) de Postgres. Eloquent no maneja arrays de
Postgres de forma nativa, así que se resuelve con SQL crudo y un cast explícito
(`app/Casts/DomosIdCast.php` y `PlanController::guardarDomos()`). Después de instalar, prueba
crear/editar un plan y confirma en Supabase que `domos_id` quedó bien guardado antes de
pasarlo a producción con el equipo.
