<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ClaseDomo;
use App\Support\RegistradorBitacora;
use Illuminate\Http\Request;

class ClaseDomoController extends Controller
{
    public function store(Request $request)
    {
        $datos = $request->validate(['nombre' => ['required', 'string', 'max:255', 'unique:clase_domo,nombre']]);

        $clase = ClaseDomo::create($datos);
        RegistradorBitacora::registrar('domos', 'crear', "Creó la clase de domo «{$clase->nombre}»", null, $clase->toArray());

        return back()->with('ok', 'Clase de domo creada.');
    }

    public function update(Request $request, ClaseDomo $claseDomo)
    {
        $datos = $request->validate([
            'nombre' => ['required', 'string', 'max:255', 'unique:clase_domo,nombre,'.$claseDomo->id],
        ]);

        $anterior = $claseDomo->toArray();
        $claseDomo->update($datos);
        RegistradorBitacora::registrar('domos', 'editar', "Editó la clase de domo «{$claseDomo->nombre}»", $anterior, $claseDomo->toArray());

        return back()->with('ok', 'Clase de domo actualizada.');
    }

    public function destroy(ClaseDomo $claseDomo)
    {
        if ($claseDomo->domos()->exists()) {
            return back()->with('error', 'No se puede eliminar: hay domos que usan esta clase.');
        }

        $anterior = $claseDomo->toArray();
        $nombre = $claseDomo->nombre;
        $claseDomo->delete();
        RegistradorBitacora::registrar('domos', 'eliminar', "Eliminó la clase de domo «{$nombre}»", $anterior, null);

        return back()->with('ok', 'Clase de domo eliminada.');
    }
}
