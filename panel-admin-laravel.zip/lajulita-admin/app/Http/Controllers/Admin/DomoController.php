<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ClaseDomo;
use App\Models\Domo;
use App\Support\RegistradorBitacora;
use Illuminate\Http\Request;

class DomoController extends Controller
{
    public function index()
    {
        $domos = Domo::with('claseDomo')->orderBy('id')->get();
        $clases = ClaseDomo::orderBy('nombre')->get();

        return view('admin.domos.index', compact('domos', 'clases'));
    }

    public function store(Request $request)
    {
        $datos = $this->validarDatos($request);

        $domo = Domo::create($datos);
        RegistradorBitacora::registrar('domos', 'crear', "Creó el domo #{$domo->id}", null, $domo->toArray());

        return back()->with('ok', 'Domo creado.');
    }

    public function update(Request $request, Domo $domo)
    {
        $datos = $this->validarDatos($request);

        $anterior = $domo->toArray();
        $domo->update($datos);
        RegistradorBitacora::registrar('domos', 'editar', "Editó el domo #{$domo->id}", $anterior, $domo->toArray());

        return back()->with('ok', 'Domo actualizado.');
    }

    public function destroy(Domo $domo)
    {
        try {
            $anterior = $domo->toArray();
            $domo->delete();
            RegistradorBitacora::registrar('domos', 'eliminar', "Eliminó el domo #{$domo->id}", $anterior, null);

            return back()->with('ok', 'Domo eliminado.');
        } catch (\Illuminate\Database\QueryException) {
            // El trigger domos_bloquear_borrado de sql/schema.sql lo impide si algún plan lo usa.
            return back()->with('error', 'No se puede eliminar: hay planes que incluyen este domo.');
        }
    }

    private function validarDatos(Request $request): array
    {
        return $request->validate([
            'clase' => ['required', 'integer', 'exists:clase_domo,id'],
            'opcion' => ['nullable', 'string', 'max:255'],
            'capacidad_max' => ['required', 'integer', 'min:1'],
        ], [], [
            'clase' => 'clase de domo',
            'opcion' => 'para quién es',
            'capacidad_max' => 'capacidad máxima',
        ]);
    }
}
