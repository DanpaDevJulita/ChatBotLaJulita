<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Adicional;
use App\Models\Bitacora;
use App\Models\Domo;
use App\Models\Faq;
use App\Models\Plan;
use App\Models\Politica;
use App\Models\Promocion;
use App\Models\Recargo;

class DashboardController extends Controller
{
    public function index()
    {
        $tarjetas = [
            'planes_activos' => Plan::where('activo', true)->count(),
            'domos' => Domo::count(),
            'adicionales_activos' => Adicional::where('estado', true)->count(),
            'recargos_activos' => Recargo::where('activo', true)->count(),
            'promociones_vigentes' => Promocion::where('activo', true)
                ->where(fn ($q) => $q->whereNull('fecha_fin')->orWhereDate('fecha_fin', '>=', now()))
                ->count(),
            'politicas' => Politica::count(),
            'faq' => Faq::count(),
        ];

        $ultimosCambios = Bitacora::with('usuario')->latest('created_at')->limit(10)->get();

        return view('admin.dashboard', compact('tarjetas', 'ultimosCambios'));
    }
}
