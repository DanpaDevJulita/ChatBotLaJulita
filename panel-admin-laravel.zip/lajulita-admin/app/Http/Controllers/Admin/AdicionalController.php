<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Adicional;
use App\Models\TipoAdicional;
use App\Support\RegistradorBitacora;
use Illuminate\Http\Request;

class AdicionalController extends Controller
{
    public function index()
    {
        $adicionales = Adicional::with('tipoAdicional')->orderBy('id')->get();
        $tipos = TipoAdicional::orderBy('nombre')->get();

        return view('admin.adicionales.index', compact('adicionales', 'tipos'));
    }

    public function store(Request $request)
    {
        $datos = $this->validarDatos($request);

        $adicional = Adicional::create($datos);
        RegistradorBitacora::registrar('adicionales', 'crear', "Creó el adicional «{$adicional->nombre}»", null, $adicional->toArray());

        return back()->with('ok', 'Adicional creado.');
    }

    public function update(Request $request, Adicional $adicional)
    {
        $datos = $this->validarDatos($request);

        $anterior = $adicional->toArray();
        $adicional->update($datos);
        RegistradorBitacora::registrar('adicionales', 'editar', "Editó el adicional «{$adicional->nombre}»", $anterior, $adicional->toArray());

        return back()->with('ok', 'Adicional actualizado.');
    }

    public function destroy(Adicional $adicional)
    {
        $anterior = $adicional->toArray();
        $nombre = $adicional->nombre;
        $adicional->delete();
        RegistradorBitacora::registrar('adicionales', 'eliminar', "Eliminó el adicional «{$nombre}»", $anterior, null);

        return back()->with('ok', 'Adicional eliminado.');
    }

    private function validarDatos(Request $request): array
    {
        $datos = $request->validate([
            'nombre' => ['required', 'string', 'max:255'],
            'descripcion' => ['nullable', 'string'],
            'precio' => ['nullable', 'numeric', 'min:0'],
            'tipo_adicional_id' => ['required', 'integer', 'exists:tipo_adicional,id'],
        ], [], [
            'nombre' => 'nombre',
            'tipo_adicional_id' => 'tipo de adicional',
        ]);

        $datos['estado'] = $request->boolean('estado');

        return $datos;
    }
}
