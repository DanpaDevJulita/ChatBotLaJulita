<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Models\Recargo;
use App\Support\RegistradorBitacora;
use Illuminate\Http\Request;

/** Recargos de niños (por rango de edad) y mascotas — ver sql/recargos.sql del bot. */
class RecargoController extends Controller
{
    public function index()
    {
        $recargos = Recargo::with('plan')->orderByRaw("tipo, edad_min nulls first")->get();
        $planes = Plan::orderBy('nombre')->get();

        return view('admin.recargos.index', compact('recargos', 'planes'));
    }

    public function store(Request $request)
    {
        $datos = $this->validarDatos($request);

        $recargo = Recargo::create($datos);
        RegistradorBitacora::registrar('recargos', 'crear', "Creó el recargo «{$recargo->nombre}»", null, $recargo->toArray());

        return back()->with('ok', 'Recargo creado.');
    }

    public function update(Request $request, Recargo $recargo)
    {
        $datos = $this->validarDatos($request);

        $anterior = $recargo->toArray();
        $recargo->update($datos);
        RegistradorBitacora::registrar('recargos', 'editar', "Editó el recargo «{$recargo->nombre}»", $anterior, $recargo->toArray());

        return back()->with('ok', 'Recargo actualizado.');
    }

    public function destroy(Recargo $recargo)
    {
        $anterior = $recargo->toArray();
        $nombre = $recargo->nombre;
        $recargo->delete();
        RegistradorBitacora::registrar('recargos', 'eliminar', "Eliminó el recargo «{$nombre}»", $anterior, null);

        return back()->with('ok', 'Recargo eliminado.');
    }

    private function validarDatos(Request $request): array
    {
        $datos = $request->validate([
            'tipo' => ['required', 'in:nino,mascota'],
            'nombre' => ['required', 'string', 'max:255'],
            'descripcion' => ['nullable', 'string'],
            'precio' => ['required', 'numeric', 'min:0'],
            'edad_min' => ['nullable', 'integer', 'min:0', 'required_if:tipo,nino'],
            'edad_max' => ['nullable', 'integer', 'min:0', 'gte:edad_min'],
            'plan_id' => ['nullable', 'integer', 'exists:planes,id'],
        ], [], [
            'tipo' => 'tipo',
            'edad_min' => 'edad mínima',
            'edad_max' => 'edad máxima',
            'plan_id' => 'plan específico',
        ]);

        // Un recargo de mascota no maneja rango de edad.
        if ($datos['tipo'] === 'mascota') {
            $datos['edad_min'] = null;
            $datos['edad_max'] = null;
        }

        $datos['activo'] = $request->boolean('activo');

        return $datos;
    }
}
