<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Models\Promocion;
use App\Support\RegistradorBitacora;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class PromocionController extends Controller
{
    public function index()
    {
        $promociones = Promocion::with('plan')->latest('id')->get();
        $planes = Plan::orderBy('nombre')->get();

        return view('admin.promociones.index', compact('promociones', 'planes'));
    }

    public function store(Request $request)
    {
        $datos = $this->validarDatos($request);

        $promocion = Promocion::create($datos);
        RegistradorBitacora::registrar('promociones', 'crear', "Creó la promoción «{$promocion->nombre}»", null, $promocion->toArray());

        return back()->with('ok', 'Promoción creada.');
    }

    public function update(Request $request, Promocion $promocion)
    {
        $datos = $this->validarDatos($request);

        $anterior = $promocion->toArray();
        $promocion->update($datos);
        RegistradorBitacora::registrar('promociones', 'editar', "Editó la promoción «{$promocion->nombre}»", $anterior, $promocion->toArray());

        return back()->with('ok', 'Promoción actualizada.');
    }

    public function destroy(Promocion $promocion)
    {
        $anterior = $promocion->toArray();
        $nombre = $promocion->nombre;
        $promocion->delete();
        RegistradorBitacora::registrar('promociones', 'eliminar', "Eliminó la promoción «{$nombre}»", $anterior, null);

        return back()->with('ok', 'Promoción eliminada.');
    }

    private function validarDatos(Request $request): array
    {
        $datos = $request->validate([
            'nombre' => ['required', 'string', 'max:255'],
            'descripcion' => ['nullable', 'string'],
            'tipo' => ['required', 'in:porcentaje,monto_fijo'],
            'valor' => [
                'required',
                'numeric',
                'min:0',
                Rule::when($request->input('tipo') === 'porcentaje', ['max:100']),
            ],
            'codigo' => ['nullable', 'string', 'max:50', 'alpha_dash'],
            'plan_id' => ['nullable', 'integer', 'exists:planes,id'],
            'fecha_inicio' => ['nullable', 'date'],
            'fecha_fin' => ['nullable', 'date', 'after_or_equal:fecha_inicio'],
        ], [
            'valor.max' => 'Un descuento en porcentaje no puede pasar de 100.',
        ], [
            'tipo' => 'tipo de descuento',
            'codigo' => 'código',
            'plan_id' => 'plan específico',
            'fecha_inicio' => 'fecha de inicio',
            'fecha_fin' => 'fecha de fin',
        ]);

        $datos['codigo'] = $datos['codigo'] ? strtoupper($datos['codigo']) : null;
        $datos['activo'] = $request->boolean('activo');

        return $datos;
    }
}
