<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Faq;
use App\Support\RegistradorBitacora;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class FaqController extends Controller
{
    public function index()
    {
        $faqs = Faq::orderBy('tema')->get();

        return view('admin.faq.index', compact('faqs'));
    }

    public function store(Request $request)
    {
        $datos = $request->validate([
            'tema' => ['required', 'string', 'max:100'],
            'pregunta_ejemplo' => ['nullable', 'string', 'max:255'],
            'respuesta' => ['required', 'string'],
        ]);

        $datos['tema'] = Str::slug($datos['tema'], '_');

        $faq = Faq::create($datos);
        RegistradorBitacora::registrar('faq', 'crear', "Creó la pregunta frecuente «{$faq->tema}»", null, $faq->toArray());

        return back()->with('ok', 'Pregunta frecuente creada.');
    }

    public function update(Request $request, Faq $faq)
    {
        $datos = $request->validate([
            'pregunta_ejemplo' => ['nullable', 'string', 'max:255'],
            'respuesta' => ['required', 'string'],
        ]);

        $anterior = $faq->toArray();
        $faq->update($datos);
        RegistradorBitacora::registrar('faq', 'editar', "Editó la pregunta frecuente «{$faq->tema}»", $anterior, $faq->toArray());

        return back()->with('ok', 'Pregunta frecuente actualizada.');
    }

    public function destroy(Faq $faq)
    {
        $anterior = $faq->toArray();
        $tema = $faq->tema;
        $faq->delete();
        RegistradorBitacora::registrar('faq', 'eliminar', "Eliminó la pregunta frecuente «{$tema}»", $anterior, null);

        return back()->with('ok', 'Pregunta frecuente eliminada.');
    }
}
