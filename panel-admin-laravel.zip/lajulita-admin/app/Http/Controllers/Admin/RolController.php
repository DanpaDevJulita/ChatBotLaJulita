<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permiso;
use App\Models\Rol;
use App\Support\RegistradorBitacora;
use Illuminate\Http\Request;

class RolController extends Controller
{
    public function index()
    {
        $roles = Rol::with('permisos')->orderBy('nombre')->get();
        $permisosPorModulo = Permiso::orderBy('modulo')->get()->groupBy('modulo');

        return view('admin.roles.index', compact('roles', 'permisosPorModulo'));
    }

    public function store(Request $request)
    {
        $datos = $request->validate([
            'nombre' => ['required', 'string', 'max:255', 'unique:roles,nombre'],
            'descripcion' => ['nullable', 'string', 'max:255'],
        ]);

        $rol = Rol::create($datos);
        $rol->permisos()->sync($request->input('permisos', []));

        RegistradorBitacora::registrar('roles', 'crear', "Creó el rol «{$rol->nombre}»");

        return back()->with('ok', 'Rol creado.');
    }

    public function update(Request $request, Rol $rol)
    {
        $datos = $request->validate([
            'nombre' => ['required', 'string', 'max:255', 'unique:roles,nombre,'.$rol->id],
            'descripcion' => ['nullable', 'string', 'max:255'],
        ]);

        $rol->update($datos);
        $rol->permisos()->sync($request->input('permisos', []));

        RegistradorBitacora::registrar('roles', 'editar', "Editó el rol «{$rol->nombre}» y sus permisos");

        return back()->with('ok', 'Rol actualizado.');
    }

    public function destroy(Rol $rol)
    {
        if ($rol->usuarios()->exists()) {
            return back()->with('error', 'No se puede eliminar: hay usuarios con este rol.');
        }

        $nombre = $rol->nombre;
        $rol->delete();
        RegistradorBitacora::registrar('roles', 'eliminar', "Eliminó el rol «{$nombre}»");

        return back()->with('ok', 'Rol eliminado.');
    }
}
