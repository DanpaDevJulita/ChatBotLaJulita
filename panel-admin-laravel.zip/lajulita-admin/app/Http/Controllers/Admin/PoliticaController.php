<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Politica;
use App\Support\RegistradorBitacora;
use Illuminate\Http\Request;

class PoliticaController extends Controller
{
    public function index()
    {
        $politicas = Politica::orderBy('clave')->get();

        return view('admin.politicas.index', compact('politicas'));
    }

    public function store(Request $request)
    {
        $datos = $this->validarDatos($request, true);

        $politica = Politica::create($datos);
        RegistradorBitacora::registrar('politicas', 'crear', "Creó la política «{$politica->clave}»", null, $politica->toArray());

        return back()->with('ok', 'Política creada.');
    }

    public function update(Request $request, Politica $politica)
    {
        $datos = $this->validarDatos($request, false);

        $anterior = $politica->toArray();
        $politica->update($datos);
        RegistradorBitacora::registrar('politicas', 'editar', "Editó la política «{$politica->clave}»", $anterior, $politica->toArray());

        return back()->with('ok', 'Política actualizada. El bot la usa a los 30 segundos como máximo.');
    }

    public function destroy(Politica $politica)
    {
        $anterior = $politica->toArray();
        $clave = $politica->clave;
        $politica->delete();
        RegistradorBitacora::registrar('politicas', 'eliminar', "Eliminó la política «{$clave}»", $anterior, null);

        return back()->with('ok', 'Política eliminada.');
    }

    private function validarDatos(Request $request, bool $esNueva): array
    {
        $reglasClave = $esNueva ? ['required', 'string', 'max:100', 'unique:politicas,clave'] : ['prohibited'];

        $datos = $request->validate([
            'clave' => $reglasClave,
            'titulo' => ['nullable', 'string', 'max:255'],
            'contenido' => ['required', 'string'],
        ]);

        if (! $esNueva) {
            unset($datos['clave']);
        } else {
            $datos['clave'] = \Illuminate\Support\Str::slug($datos['clave'], '_');
        }

        $datos['activo'] = $request->boolean('activo');

        return $datos;
    }
}
