<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TipoAdicional;
use App\Support\RegistradorBitacora;
use Illuminate\Http\Request;

class TipoAdicionalController extends Controller
{
    public function store(Request $request)
    {
        $datos = $request->validate(['nombre' => ['required', 'string', 'max:255', 'unique:tipo_adicional,nombre']]);

        $tipo = TipoAdicional::create($datos);
        RegistradorBitacora::registrar('adicionales', 'crear', "Creó el tipo de adicional «{$tipo->nombre}»", null, $tipo->toArray());

        return back()->with('ok', 'Tipo de adicional creado.');
    }

    public function update(Request $request, TipoAdicional $tipoAdicional)
    {
        $datos = $request->validate([
            'nombre' => ['required', 'string', 'max:255', 'unique:tipo_adicional,nombre,'.$tipoAdicional->id],
        ]);

        $anterior = $tipoAdicional->toArray();
        $tipoAdicional->update($datos);
        RegistradorBitacora::registrar('adicionales', 'editar', "Editó el tipo de adicional «{$tipoAdicional->nombre}»", $anterior, $tipoAdicional->toArray());

        return back()->with('ok', 'Tipo de adicional actualizado.');
    }

    public function destroy(TipoAdicional $tipoAdicional)
    {
        if ($tipoAdicional->adicionales()->exists()) {
            return back()->with('error', 'No se puede eliminar: hay adicionales que usan este tipo.');
        }

        $anterior = $tipoAdicional->toArray();
        $nombre = $tipoAdicional->nombre;
        $tipoAdicional->delete();
        RegistradorBitacora::registrar('adicionales', 'eliminar', "Eliminó el tipo de adicional «{$nombre}»", $anterior, null);

        return back()->with('ok', 'Tipo de adicional eliminado.');
    }
}
