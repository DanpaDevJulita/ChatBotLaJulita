<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ClaseDomo;
use App\Models\Domo;
use App\Models\Plan;
use App\Support\RegistradorBitacora;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PlanController extends Controller
{
    public function index()
    {
        $planes = Plan::orderBy('id')->get();
        $domos = Domo::with('claseDomo')->orderBy('id')->get();

        return view('admin.planes.index', compact('planes', 'domos'));
    }

    public function store(Request $request)
    {
        $datos = $this->validarDatos($request);
        $domosId = $datos['domos_id'];
        unset($datos['domos_id']);

        $plan = Plan::create($datos);
        $this->guardarDomos($plan, $domosId);

        RegistradorBitacora::registrar('planes', 'crear', "Creó el plan «{$plan->nombre}»", null, $plan->fresh()->toArray());

        return back()->with('ok', 'Plan creado correctamente.');
    }

    public function update(Request $request, Plan $plan)
    {
        $datos = $this->validarDatos($request);
        $domosId = $datos['domos_id'];
        unset($datos['domos_id']);

        $anterior = $plan->toArray();
        $plan->update($datos);
        $this->guardarDomos($plan, $domosId);

        RegistradorBitacora::registrar('planes', 'editar', "Editó el plan «{$plan->nombre}»", $anterior, $plan->fresh()->toArray());

        return back()->with('ok', 'Plan actualizado correctamente.');
    }

    public function destroy(Plan $plan)
    {
        $anterior = $plan->toArray();
        $nombre = $plan->nombre;
        $plan->delete();

        RegistradorBitacora::registrar('planes', 'eliminar', "Eliminó el plan «{$nombre}»", $anterior, null);

        return back()->with('ok', 'Plan eliminado.');
    }

    private function validarDatos(Request $request): array
    {
        $datos = $request->validate([
            'nombre' => ['required', 'string', 'max:255'],
            'descripcion' => ['nullable', 'string'],
            'precio_entre_semana' => ['nullable', 'numeric', 'min:0'],
            'precio_fin_de_semana' => ['nullable', 'numeric', 'min:0'],
            'precio_fin_de_semana_puente' => ['nullable', 'numeric', 'min:0'],
            'link_video' => ['nullable', 'url', 'max:2048'],
            'domos_id' => ['nullable', 'array'],
            'domos_id.*' => ['integer', 'exists:domos,id'],
        ], [], [
            'nombre' => 'nombre',
            'precio_entre_semana' => 'precio entre semana',
            'precio_fin_de_semana' => 'precio fin de semana',
            'precio_fin_de_semana_puente' => 'precio fin de semana puente/festivo',
            'link_video' => 'link del video',
        ]);

        $datos['activo'] = $request->boolean('activo');
        $datos['domos_id'] = $datos['domos_id'] ?? [];

        return $datos;
    }

    /**
     * planes.domos_id es un int[] de Postgres: se actualiza con SQL crudo y el cast explícito
     * `::int[]`, en vez de dejar que el binding normal de Eloquent lo intente (ver
     * App\Casts\DomosIdCast para el porqué completo).
     */
    private function guardarDomos(Plan $plan, array $domosId): void
    {
        $literal = '{'.implode(',', array_map('intval', $domosId)).'}';
        DB::update('update planes set domos_id = ?::int[] where id = ?', [$literal, $plan->id]);
    }
}
