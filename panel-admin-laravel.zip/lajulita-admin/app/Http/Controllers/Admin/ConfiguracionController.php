<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Configuracion;
use App\Models\FechaBloqueada;
use App\Support\RegistradorBitacora;
use Illuminate\Http\Request;

/** Horarios generales (check-in/check-out, etc.) y fechas no disponibles para reservar. */
class ConfiguracionController extends Controller
{
    public function index()
    {
        $configuraciones = Configuracion::orderBy('clave')->get();
        $fechasBloqueadas = FechaBloqueada::orderBy('fecha')->get();

        return view('admin.configuracion.index', compact('configuraciones', 'fechasBloqueadas'));
    }

    public function guardarConfiguracion(Request $request)
    {
        $datos = $request->validate([
            'clave' => ['required', 'string', 'max:100'],
            'valor' => ['required', 'string'],
        ]);

        $anterior = Configuracion::find($datos['clave'])?->toArray();
        $config = Configuracion::updateOrCreate(['clave' => $datos['clave']], ['valor' => $datos['valor']]);
        RegistradorBitacora::registrar('configuracion', 'editar', "Actualizó «{$config->clave}»", $anterior, $config->toArray());

        return back()->with('ok', 'Configuración guardada.');
    }

    public function agregarFechaBloqueada(Request $request)
    {
        $datos = $request->validate([
            'fecha' => ['required', 'date', 'after_or_equal:today'],
            'motivo' => ['nullable', 'string', 'max:255'],
        ]);

        $fecha = FechaBloqueada::create($datos);
        RegistradorBitacora::registrar('configuracion', 'crear', "Bloqueó la fecha {$fecha->fecha}", null, $fecha->toArray());

        return back()->with('ok', 'Fecha bloqueada.');
    }

    public function eliminarFechaBloqueada(FechaBloqueada $fechaBloqueada)
    {
        $anterior = $fechaBloqueada->toArray();
        $fecha = $fechaBloqueada->fecha;
        $fechaBloqueada->delete();
        RegistradorBitacora::registrar('configuracion', 'eliminar', "Quitó el bloqueo de la fecha {$fecha}", $anterior, null);

        return back()->with('ok', 'Fecha desbloqueada.');
    }
}
