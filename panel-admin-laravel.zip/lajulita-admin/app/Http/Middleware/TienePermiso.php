<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Uso en routes/web.php: ->middleware('permiso:planes.ver')
 *
 * Si el usuario no está autenticado, el middleware `auth` (que siempre va antes en el grupo de
 * rutas) ya lo manda a /login. Acá solo nos preocupamos de la autorización: autenticado pero
 * sin el permiso puntual -> 403.
 */
class TienePermiso
{
    public function handle(Request $request, Closure $next, string $permiso): Response
    {
        $usuario = $request->user();

        if (! $usuario || ! $usuario->activo || ! $usuario->hasPermiso($permiso)) {
            abort(403, 'No tienes permiso para ver esta sección.');
        }

        return $next($request);
    }
}
