<?php

namespace App\Casts;

use Illuminate\Contracts\Database\Eloquent\CastsAttributes;

/**
 * `planes.domos_id` es un int[] de Postgres (ver sql/schema.sql PARTE 2 del bot). El driver
 * pgsql de PDO no sabe convertir arrays de Postgres solo, así que:
 *
 *  - LECTURA: PDO devuelve el valor crudo como el texto "{1,2,3}" (o null) -> lo convertimos a
 *    un array de PHP de enteros.
 *  - ESCRITURA: a propósito NO se escribe por acá (devolvemos null y excluimos domos_id de los
 *    $fillable de Plan). Guardar un int[] a través del binding normal de Eloquent no aplica el
 *    cast `::int[]` que Postgres necesita del lado de la base. En vez de eso,
 *    PlanController::guardarDomos() hace un UPDATE crudo con el cast explícito en el SQL. Ver
 *    ese método para el detalle.
 */
class DomosIdCast implements CastsAttributes
{
    public function get($model, string $key, $value, array $attributes): array
    {
        if ($value === null || $value === '') {
            return [];
        }

        if (is_array($value)) {
            return array_map('intval', $value);
        }

        $limpio = trim((string) $value, "{}");

        if ($limpio === '') {
            return [];
        }

        return array_map('intval', explode(',', $limpio));
    }

    public function set($model, string $key, $value, array $attributes)
    {
        // Ver el comentario de la clase: domos_id se actualiza aparte, con SQL crudo.
        return null;
    }
}
