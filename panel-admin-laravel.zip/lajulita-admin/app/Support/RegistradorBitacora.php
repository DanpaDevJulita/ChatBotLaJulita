<?php

namespace App\Support;

use App\Models\Bitacora;
use Illuminate\Support\Facades\Auth;

/**
 * Un solo lugar para dejar constancia de cada creación/edición/borrado hecho desde el panel.
 * Se llama a mano al final de cada store/update/destroy de los controladores de Admin — nada
 * de magia automática con observers, para que sea fácil de leer qué se registra y cuándo.
 */
class RegistradorBitacora
{
    public static function registrar(
        string $modulo,
        string $accion,
        string $descripcion,
        ?array $datosAnteriores = null,
        ?array $datosNuevos = null,
    ): void {
        Bitacora::create([
            'user_id' => Auth::id(),
            'modulo' => $modulo,
            'accion' => $accion,
            'descripcion' => $descripcion,
            'datos_anteriores' => $datosAnteriores,
            'datos_nuevos' => $datosNuevos,
        ]);
    }
}
