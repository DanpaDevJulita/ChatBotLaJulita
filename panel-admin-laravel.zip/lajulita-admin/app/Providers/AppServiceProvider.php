<?php

namespace App\Providers;

use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Si el panel queda detrás de un proxy/balanceador con HTTPS (Render, Railway, un
        // servidor con Nginx haciendo TLS-termination, etc.), esto evita que Laravel genere
        // enlaces con http:// en vez de https://.
        if (env('APP_URL') && str_starts_with((string) env('APP_URL'), 'https://')) {
            URL::forceScheme('https');
        }
    }
}
