<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Un permiso puntual, ej. clave="planes.editar", modulo="planes". La clave es lo que se checa
 * en código (middleware `permiso:planes.editar`, o $user->hasPermiso('planes.editar')); modulo
 * y etiqueta son solo para agrupar bonito en la pantalla de Roles.
 */
class Permiso extends Model
{
    protected $table = 'permisos';

    public $timestamps = false;

    protected $fillable = ['clave', 'modulo', 'etiqueta'];

    public function roles()
    {
        return $this->belongsToMany(Rol::class, 'rol_permiso', 'permiso_id', 'rol_id');
    }
}
