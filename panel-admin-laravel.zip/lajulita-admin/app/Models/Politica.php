<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Tabla `politicas`: los textos oficiales que el bot le manda TAL CUAL al cliente (nunca los
 * reformula). La clave primaria es `clave` (texto), no un id numérico. Editar acá con cuidado:
 * lo que se guarde es lo que el cliente lee, palabra por palabra (formato WhatsApp: *negrita*
 * con un solo asterisco).
 */
class Politica extends Model
{
    protected $table = 'politicas';

    protected $primaryKey = 'clave';

    public $incrementing = false;

    protected $keyType = 'string';

    const CREATED_AT = null;

    const UPDATED_AT = 'updated_at';

    protected $fillable = ['clave', 'titulo', 'contenido', 'activo'];

    protected function casts(): array
    {
        return ['activo' => 'boolean'];
    }
}
