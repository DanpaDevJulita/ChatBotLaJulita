<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Tabla `recargos`: lo que se cobra APARTE del plan (niños por rango de edad y mascotas). Ver
 * sql/recargos.sql del bot para el contexto completo de por qué existe esta tabla.
 */
class Recargo extends Model
{
    protected $table = 'recargos';

    const UPDATED_AT = 'updated_at';

    const CREATED_AT = null;

    protected $fillable = [
        'tipo',
        'nombre',
        'descripcion',
        'precio',
        'edad_min',
        'edad_max',
        'plan_id',
        'activo',
    ];

    protected function casts(): array
    {
        return [
            'precio' => 'decimal:2',
            'activo' => 'boolean',
        ];
    }

    public function plan()
    {
        return $this->belongsTo(Plan::class, 'plan_id');
    }
}
