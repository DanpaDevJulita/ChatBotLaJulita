<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/** Tabla `configuracion`: clave/valor de texto libre (hoy, horarios de check-in/check-out). */
class Configuracion extends Model
{
    protected $table = 'configuracion';

    protected $primaryKey = 'clave';

    public $incrementing = false;

    protected $keyType = 'string';

    const CREATED_AT = null;

    const UPDATED_AT = 'updated_at';

    protected $fillable = ['clave', 'valor'];
}
