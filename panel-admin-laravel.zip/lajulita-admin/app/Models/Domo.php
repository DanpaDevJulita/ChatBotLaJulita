<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Domo extends Model
{
    protected $table = 'domos';

    public $timestamps = false;

    protected $fillable = ['clase', 'opcion', 'capacidad_max'];

    public function claseDomo()
    {
        return $this->belongsTo(ClaseDomo::class, 'clase');
    }
}
