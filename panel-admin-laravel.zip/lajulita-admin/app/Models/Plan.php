<?php

namespace App\Models;

use App\Casts\DomosIdCast;
use Illuminate\Database\Eloquent\Model;

/**
 * Tabla `planes` (sql/schema.sql PARTE 2 del bot). OJO: no existe columna `capacidad` ni
 * `precio` sueltos — hay tres precios según el día, y la capacidad sale de los domos asociados.
 */
class Plan extends Model
{
    protected $table = 'planes';

    public $timestamps = false;

    // domos_id se maneja aparte (ver App\Casts\DomosIdCast y PlanController::guardarDomos).
    protected $fillable = [
        'nombre',
        'descripcion',
        'precio_entre_semana',
        'precio_fin_de_semana',
        'precio_fin_de_semana_puente',
        'link_video',
        'activo',
    ];

    protected function casts(): array
    {
        return [
            'precio_entre_semana' => 'decimal:2',
            'precio_fin_de_semana' => 'decimal:2',
            'precio_fin_de_semana_puente' => 'decimal:2',
            'activo' => 'boolean',
            'domos_id' => DomosIdCast::class,
        ];
    }

    public function recargos()
    {
        return $this->hasMany(Recargo::class, 'plan_id');
    }

    public function promociones()
    {
        return $this->hasMany(Promocion::class, 'plan_id');
    }
}
