<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * `bitacora_cambios` — quién cambió qué desde el panel. No es para el bot ni para el cliente:
 * es la trazabilidad que le da confianza al equipo de que varios vendedores pueden editar el
 * catálogo sin perder de vista quién tocó qué y cuándo. Ver App\Support\RegistradorBitacora.
 */
class Bitacora extends Model
{
    protected $table = 'bitacora_cambios';

    const CREATED_AT = 'created_at';

    const UPDATED_AT = null;

    protected $fillable = [
        'user_id',
        'modulo',
        'accion',
        'descripcion',
        'datos_anteriores',
        'datos_nuevos',
    ];

    protected function casts(): array
    {
        return [
            'datos_anteriores' => 'array',
            'datos_nuevos' => 'array',
        ];
    }

    public function usuario()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
