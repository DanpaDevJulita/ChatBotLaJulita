<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class FechaBloqueada extends Model
{
    use HasUuids;

    protected $table = 'fechas_bloqueadas';

    public $timestamps = false;

    protected $fillable = ['fecha', 'motivo'];
}
