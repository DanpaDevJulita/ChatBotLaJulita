<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Tabla `promociones` — NUEVA, creada por este panel (no existía en el bot). Guarda descuentos
 * que el equipo comercial puede definir (porcentaje o monto fijo), con vigencia por fechas y,
 * opcionalmente, un código y un plan puntual.
 *
 * Importante: el bot todavía NO lee esta tabla — hoy es solo para que el equipo administre y
 * lleve el control de las promociones vigentes desde un solo lugar. Conectarla a la lógica de
 * ventas del bot (para que el precio final la tenga en cuenta) queda como un paso futuro, fuera
 * del alcance de este panel; cuando se haga, lo natural es que sea una tabla de solo lectura
 * más para el bot, igual que `recargos`.
 */
class Promocion extends Model
{
    protected $table = 'promociones';

    protected $fillable = [
        'nombre',
        'descripcion',
        'tipo',
        'valor',
        'codigo',
        'plan_id',
        'fecha_inicio',
        'fecha_fin',
        'activo',
    ];

    protected function casts(): array
    {
        return [
            'valor' => 'decimal:2',
            'fecha_inicio' => 'date',
            'fecha_fin' => 'date',
            'activo' => 'boolean',
        ];
    }

    public function plan()
    {
        return $this->belongsTo(Plan::class, 'plan_id');
    }

    public function vigente(): bool
    {
        if (! $this->activo) {
            return false;
        }

        $hoy = now()->toDateString();

        if ($this->fecha_inicio && $hoy < $this->fecha_inicio->toDateString()) {
            return false;
        }

        if ($this->fecha_fin && $hoy > $this->fecha_fin->toDateString()) {
            return false;
        }

        return true;
    }
}
