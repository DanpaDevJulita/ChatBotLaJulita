<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Tabla `adicionales`. OJO: la columna de activo/inactivo se llama `estado` (booleano), NO
 * `activo` — a diferencia de `planes` y `promociones`. Es el mismo nombre que usa el bot
 * (catalogoRepo.ts), así que se respeta acá para no crear una segunda convención.
 */
class Adicional extends Model
{
    protected $table = 'adicionales';

    public $timestamps = false;

    protected $fillable = [
        'nombre',
        'descripcion',
        'precio',
        'tipo_adicional_id',
        'estado',
    ];

    protected function casts(): array
    {
        return [
            'precio' => 'decimal:2',
            'estado' => 'boolean',
        ];
    }

    public function tipoAdicional()
    {
        return $this->belongsTo(TipoAdicional::class, 'tipo_adicional_id');
    }
}
