<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClaseDomo extends Model
{
    protected $table = 'clase_domo';

    public $timestamps = false;

    protected $fillable = ['nombre'];

    public function domos()
    {
        return $this->hasMany(Domo::class, 'clase');
    }
}
