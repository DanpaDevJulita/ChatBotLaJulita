<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TipoAdicional extends Model
{
    protected $table = 'tipo_adicional';

    public $timestamps = false;

    protected $fillable = ['nombre'];

    public function adicionales()
    {
        return $this->hasMany(Adicional::class, 'tipo_adicional_id');
    }
}
