<?php

use App\Http\Controllers\Admin\AdicionalController;
use App\Http\Controllers\Admin\ClaseDomoController;
use App\Http\Controllers\Admin\ConfiguracionController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\DomoController;
use App\Http\Controllers\Admin\FaqController;
use App\Http\Controllers\Admin\PlanController;
use App\Http\Controllers\Admin\PoliticaController;
use App\Http\Controllers\Admin\PromocionController;
use App\Http\Controllers\Admin\RecargoController;
use App\Http\Controllers\Admin\RolController;
use App\Http\Controllers\Admin\TipoAdicionalController;
use App\Http\Controllers\Admin\UsuarioController;
use App\Http\Controllers\Auth\LoginController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('admin.dashboard'));

// --- Login (público) ------------------------------------------------------------------------
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'mostrarFormulario'])->name('login');
    Route::post('/login', [LoginController::class, 'iniciarSesion'])->name('login.intentar');
});
Route::post('/logout', [LoginController::class, 'cerrarSesion'])->middleware('auth')->name('logout');

// --- Panel de administración (todo requiere sesión iniciada) --------------------------------
Route::middleware('auth')->prefix('admin')->name('admin.')->group(function () {

    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    // Planes ------------------------------------------------------------------------------
    Route::middleware('permiso:planes.ver')->group(function () {
        Route::get('/planes', [PlanController::class, 'index'])->name('planes.index');
    });
    Route::post('/planes', [PlanController::class, 'store'])->middleware('permiso:planes.crear')->name('planes.store');
    Route::put('/planes/{plan}', [PlanController::class, 'update'])->middleware('permiso:planes.editar')->name('planes.update');
    Route::delete('/planes/{plan}', [PlanController::class, 'destroy'])->middleware('permiso:planes.eliminar')->name('planes.destroy');

    // Domos y clases de domo ---------------------------------------------------------------
    Route::middleware('permiso:domos.ver')->group(function () {
        Route::get('/domos', [DomoController::class, 'index'])->name('domos.index');
    });
    Route::post('/domos', [DomoController::class, 'store'])->middleware('permiso:domos.crear')->name('domos.store');
    Route::put('/domos/{domo}', [DomoController::class, 'update'])->middleware('permiso:domos.editar')->name('domos.update');
    Route::delete('/domos/{domo}', [DomoController::class, 'destroy'])->middleware('permiso:domos.eliminar')->name('domos.destroy');

    Route::post('/clases-domo', [ClaseDomoController::class, 'store'])->middleware('permiso:domos.crear')->name('clases-domo.store');
    Route::put('/clases-domo/{claseDomo}', [ClaseDomoController::class, 'update'])->middleware('permiso:domos.editar')->name('clases-domo.update');
    Route::delete('/clases-domo/{claseDomo}', [ClaseDomoController::class, 'destroy'])->middleware('permiso:domos.eliminar')->name('clases-domo.destroy');

    // Adicionales y sus tipos ---------------------------------------------------------------
    Route::middleware('permiso:adicionales.ver')->group(function () {
        Route::get('/adicionales', [AdicionalController::class, 'index'])->name('adicionales.index');
    });
    Route::post('/adicionales', [AdicionalController::class, 'store'])->middleware('permiso:adicionales.crear')->name('adicionales.store');
    Route::put('/adicionales/{adicional}', [AdicionalController::class, 'update'])->middleware('permiso:adicionales.editar')->name('adicionales.update');
    Route::delete('/adicionales/{adicional}', [AdicionalController::class, 'destroy'])->middleware('permiso:adicionales.eliminar')->name('adicionales.destroy');

    Route::post('/tipos-adicional', [TipoAdicionalController::class, 'store'])->middleware('permiso:adicionales.crear')->name('tipos-adicional.store');
    Route::put('/tipos-adicional/{tipoAdicional}', [TipoAdicionalController::class, 'update'])->middleware('permiso:adicionales.editar')->name('tipos-adicional.update');
    Route::delete('/tipos-adicional/{tipoAdicional}', [TipoAdicionalController::class, 'destroy'])->middleware('permiso:adicionales.eliminar')->name('tipos-adicional.destroy');

    // Recargos: niños y mascotas -------------------------------------------------------------
    Route::middleware('permiso:recargos.ver')->group(function () {
        Route::get('/recargos', [RecargoController::class, 'index'])->name('recargos.index');
    });
    Route::post('/recargos', [RecargoController::class, 'store'])->middleware('permiso:recargos.crear')->name('recargos.store');
    Route::put('/recargos/{recargo}', [RecargoController::class, 'update'])->middleware('permiso:recargos.editar')->name('recargos.update');
    Route::delete('/recargos/{recargo}', [RecargoController::class, 'destroy'])->middleware('permiso:recargos.eliminar')->name('recargos.destroy');

    // Políticas ------------------------------------------------------------------------------
    Route::middleware('permiso:politicas.ver')->group(function () {
        Route::get('/politicas', [PoliticaController::class, 'index'])->name('politicas.index');
    });
    Route::post('/politicas', [PoliticaController::class, 'store'])->middleware('permiso:politicas.crear')->name('politicas.store');
    Route::put('/politicas/{politica}', [PoliticaController::class, 'update'])->middleware('permiso:politicas.editar')->name('politicas.update');
    Route::delete('/politicas/{politica}', [PoliticaController::class, 'destroy'])->middleware('permiso:politicas.eliminar')->name('politicas.destroy');

    // Promociones ----------------------------------------------------------------------------
    Route::middleware('permiso:promociones.ver')->group(function () {
        Route::get('/promociones', [PromocionController::class, 'index'])->name('promociones.index');
    });
    Route::post('/promociones', [PromocionController::class, 'store'])->middleware('permiso:promociones.crear')->name('promociones.store');
    Route::put('/promociones/{promocion}', [PromocionController::class, 'update'])->middleware('permiso:promociones.editar')->name('promociones.update');
    Route::delete('/promociones/{promocion}', [PromocionController::class, 'destroy'])->middleware('permiso:promociones.eliminar')->name('promociones.destroy');

    // FAQ ------------------------------------------------------------------------------------
    Route::middleware('permiso:faq.ver')->group(function () {
        Route::get('/faq', [FaqController::class, 'index'])->name('faq.index');
    });
    Route::post('/faq', [FaqController::class, 'store'])->middleware('permiso:faq.crear')->name('faq.store');
    Route::put('/faq/{faq}', [FaqController::class, 'update'])->middleware('permiso:faq.editar')->name('faq.update');
    Route::delete('/faq/{faq}', [FaqController::class, 'destroy'])->middleware('permiso:faq.eliminar')->name('faq.destroy');

    // Configuración (horarios) + fechas bloqueadas -------------------------------------------
    Route::middleware('permiso:configuracion.ver')->group(function () {
        Route::get('/configuracion', [ConfiguracionController::class, 'index'])->name('configuracion.index');
    });
    Route::post('/configuracion', [ConfiguracionController::class, 'guardarConfiguracion'])->middleware('permiso:configuracion.editar')->name('configuracion.guardar');
    Route::post('/fechas-bloqueadas', [ConfiguracionController::class, 'agregarFechaBloqueada'])->middleware('permiso:configuracion.editar')->name('fechas-bloqueadas.store');
    Route::delete('/fechas-bloqueadas/{fechaBloqueada}', [ConfiguracionController::class, 'eliminarFechaBloqueada'])->middleware('permiso:configuracion.editar')->name('fechas-bloqueadas.destroy');

    // Usuarios -------------------------------------------------------------------------------
    Route::middleware('permiso:usuarios.ver')->group(function () {
        Route::get('/usuarios', [UsuarioController::class, 'index'])->name('usuarios.index');
    });
    Route::post('/usuarios', [UsuarioController::class, 'store'])->middleware('permiso:usuarios.crear')->name('usuarios.store');
    Route::put('/usuarios/{usuario}', [UsuarioController::class, 'update'])->middleware('permiso:usuarios.editar')->name('usuarios.update');
    Route::delete('/usuarios/{usuario}', [UsuarioController::class, 'destroy'])->middleware('permiso:usuarios.eliminar')->name('usuarios.destroy');

    // Roles y permisos -------------------------------------------------------------------------
    Route::middleware('permiso:roles.ver')->group(function () {
        Route::get('/roles', [RolController::class, 'index'])->name('roles.index');
    });
    Route::post('/roles', [RolController::class, 'store'])->middleware('permiso:roles.crear')->name('roles.store');
    Route::put('/roles/{rol}', [RolController::class, 'update'])->middleware('permiso:roles.editar')->name('roles.update');
    Route::delete('/roles/{rol}', [RolController::class, 'destroy'])->middleware('permiso:roles.eliminar')->name('roles.destroy');
});
