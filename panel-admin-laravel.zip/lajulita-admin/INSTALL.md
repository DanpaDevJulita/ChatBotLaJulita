# Instalación del panel de administración — La Julita

Este paquete **no trae `vendor/` ni el resto del esqueleto de Laravel** porque desde el
entorno donde se armó no había salida a internet para descargar paquetes de Composer. Se
resuelve en 10 minutos siguiendo estos pasos en una máquina con PHP 8.2+, Composer e internet
(tu computador, o el servidor donde vayas a alojar el panel).

## 1. Crear el proyecto Laravel base

```bash
composer create-project laravel/laravel bot-lajulita-admin "^13.0"
cd bot-lajulita-admin
composer require laravel/tinker
```

Esto te deja un Laravel 11 nuevo y 100% funcional, con su `vendor/`, su `.env` con
`APP_KEY` generada, etc.

## 2. Copiar los archivos de este paquete encima

Copia (sobrescribiendo) todo el contenido de esta carpeta dentro del proyecto que acabas de
crear, **excepto** estas rutas que ya trae Laravel y que este paquete no debe pisar:

- `vendor/`
- `.env` (usa `.env.example` de este paquete como referencia, no lo reemplaces directo si ya
  personalizaste algo en el `.env` que generó `composer create-project`)
- `bootstrap/cache/` (déjalo vacío, como está)

En Windows (PowerShell), parado en la carpeta de este paquete:

```powershell
Copy-Item -Recurse -Force .\app ..\bot-lajulita-admin\
Copy-Item -Recurse -Force .\bootstrap\app.php ..\bot-lajulita-admin\bootstrap\
Copy-Item -Recurse -Force .\bootstrap\providers.php ..\bot-lajulita-admin\bootstrap\
Copy-Item -Recurse -Force .\config ..\bot-lajulita-admin\
Copy-Item -Recurse -Force .\database ..\bot-lajulita-admin\
Copy-Item -Recurse -Force .\public ..\bot-lajulita-admin\
Copy-Item -Recurse -Force .\resources ..\bot-lajulita-admin\
Copy-Item -Recurse -Force .\routes ..\bot-lajulita-admin\
Copy-Item -Force .\.env.example ..\bot-lajulita-admin\.env.example
```

(En Mac/Linux, lo mismo con `cp -R`.)

## 3. Configurar la conexión a Supabase

Entra a tu proyecto en [supabase.com](https://supabase.com) → **Project Settings** →
**Database** → pestaña **Connection string** → **URI**. Usa la variante **"Session pooler"**
(puerto 5432): es compatible con IPv4 y sí soporta *prepared statements*, que es lo que usa
Eloquent. La variante "Transaction pooler" (puerto 6543) casi siempre falla con Eloquent.

En el `.env` del proyecto (`bot-lajulita-admin/.env`), agrega/edita:

```
DB_CONNECTION=pgsql
DB_HOST=aws-0-xxxxx.pooler.supabase.com
DB_PORT=5432
DB_DATABASE=postgres
DB_USERNAME=postgres.xxxxxxxxxxxxxxxxx
DB_PASSWORD=la-contraseña-de-tu-proyecto-supabase
DB_SCHEMA=public
DB_SSLMODE=require

SESSION_DRIVER=database
CACHE_STORE=database
QUEUE_CONNECTION=database
```

Es la **misma base de datos que ya usa el bot** (las variables `SUPABASE_URL` /
`SUPABASE_SERVICE_ROLE_KEY` del `.env` del bot apuntan al mismo proyecto de Supabase, solo que
por la API REST en vez de una conexión Postgres directa). El panel lee y escribe las mismas
tablas: `planes`, `politicas`, `domos`, `clase_domo`, `adicionales`, `tipo_adicional`,
`recargos`, `faq`, `configuracion`, `fechas_bloqueadas`.

## 4. Migrar y sembrar datos

```bash
php artisan migrate
php artisan db:seed --class=Database\\Seeders\\RolesPermisosSeeder
```

Las migraciones de las tablas del bot (`planes`, `domos`, etc.) están hechas para **no tocar
nada si esas tablas ya existen** (que es tu caso: ya están en Supabase con datos reales). Solo
crean lo que de verdad es nuevo: `roles`, `permisos`, `rol_permiso`, `users`, `promociones`,
`bitacora_cambios`, y las tablas propias de Laravel (`sessions`, `cache`, `jobs`).

El seeder crea:
- Los permisos de cada módulo (ver/crear/editar/eliminar).
- Dos roles: **Administrador** (todo) y **Vendedor** (puede editar planes, adicionales,
  recargos, promociones, políticas y FAQ, pero no eliminar ni tocar usuarios/roles/domos).
- Un primer usuario: `daniel.pataquiva@lajulitadevelopment.site` con la contraseña
  `CambiaEstaClave123` (o la que pongas en `ADMIN_PASSWORD_INICIAL` en el `.env` antes de
  sembrar). **Cámbiala apenas entres**, desde el menú Usuarios.

## 5. Probarlo local

```bash
php artisan serve
```

Entra a `http://127.0.0.1:8000`, inicia sesión, y ya deberías ver los planes, políticas,
domos, etc. que ya existen en Supabase.

## 6. Para producción

- Pon `APP_ENV=production` y `APP_DEBUG=false` en el `.env` (ya vienen así en el
  `.env.example` de este paquete).
- Sirve la carpeta `public/` con tu servidor web (Apache/Nginx) o con un panel tipo
  cPanel/Plesk apuntando el *document root* ahí.
- Corre `php artisan config:cache` y `php artisan route:cache` después de configurar el
  `.env` definitivo.
- Revisa especialmente el guardado de `domos_id` en un plan (es un `int[]` de Postgres, el
  punto más delicado de esta integración — ver el comentario en
  `app/Casts/DomosIdCast.php` y `app/Http/Controllers/Admin/PlanController.php`): crea o
  edita un plan de prueba y confirma en el SQL Editor de Supabase
  (`select id, nombre, domos_id from planes;`) que quedó guardado correctamente.

## Notas importantes

- **`promociones` y `bitacora_cambios` son tablas nuevas.** El bot todavía no lee
  `promociones` para calcular precios — hoy es solo para que el equipo comercial administre
  las promociones vigentes desde un solo lugar. Conectarla a la lógica de ventas del bot
  queda como un paso futuro (ver el comentario en `app/Models/Promocion.php`).
- **La bitácora (`bitacora_cambios`)** deja constancia de quién creó/editó/eliminó qué desde
  el panel — se ve en el Dashboard, "Últimos cambios en el catálogo".
- El panel **no reemplaza** el mini-panel que ya existe en `src/web/admin/` del bot (login con
  una sola contraseña, para FAQ/políticas/planes/adicionales básicos): puedes seguir usando
  ambos mientras migras al equipo a este panel, o apagar el viejo cuando ya no lo necesites.
