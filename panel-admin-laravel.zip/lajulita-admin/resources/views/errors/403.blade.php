<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Sin permiso · Panel La Julita</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/css/adminlte.min.css">
</head>
<body class="hold-transition login-page">
<div class="login-box text-center">
    <h1 class="display-4">403</h1>
    <p class="lead">No tienes permiso para ver esta sección.</p>
    <a href="{{ route('admin.dashboard') }}" class="btn btn-primary">Volver al dashboard</a>
</div>
</body>
</html>
