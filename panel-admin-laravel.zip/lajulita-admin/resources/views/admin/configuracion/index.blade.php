@extends('layouts.admin')

@section('titulo', 'Horarios y fechas bloqueadas')

@section('contenido')
<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Configuración general</h3></div>
            <div class="card-body p-0">
                <table class="table table-striped mb-0">
                    <thead><tr><th>Clave</th><th>Valor</th><th style="width:60px"></th></tr></thead>
                    <tbody>
                    @forelse($configuraciones as $config)
                        <tr>
                            <td><code>{{ $config->clave }}</code></td>
                            <td>{{ $config->valor }}</td>
                            <td>
                                @if(auth()->user()->hasPermiso('configuracion.editar'))
                                <button class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal-editar-config-{{ $loop->index }}"><i class="fas fa-pen"></i></button>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="3" class="text-center text-muted py-3">Sin configuración cargada todavía.</td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
            @if(auth()->user()->hasPermiso('configuracion.editar'))
            <div class="card-footer">
                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-nueva-config"><i class="fas fa-plus"></i> Agregar / actualizar clave</button>
            </div>
            @endif
        </div>
    </div>

    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Fechas bloqueadas</h3></div>
            <div class="card-body p-0">
                <table class="table table-striped mb-0">
                    <thead><tr><th>Fecha</th><th>Motivo</th><th style="width:60px"></th></tr></thead>
                    <tbody>
                    @forelse($fechasBloqueadas as $fecha)
                        <tr>
                            <td>{{ \Illuminate\Support\Carbon::parse($fecha->fecha)->format('d/m/Y') }}</td>
                            <td>{{ $fecha->motivo }}</td>
                            <td>
                                @if(auth()->user()->hasPermiso('configuracion.editar'))
                                <form action="{{ route('admin.fechas-bloqueadas.destroy', $fecha) }}" method="POST" onsubmit="return confirm('¿Desbloquear esta fecha?');">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></button>
                                </form>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="3" class="text-center text-muted py-3">No hay fechas bloqueadas.</td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
            @if(auth()->user()->hasPermiso('configuracion.editar'))
            <div class="card-footer">
                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-nueva-fecha"><i class="fas fa-plus"></i> Bloquear una fecha</button>
            </div>
            @endif
        </div>
    </div>
</div>

<div class="modal fade" id="modal-nueva-config">
    <div class="modal-dialog">
        <form action="{{ route('admin.configuracion.guardar') }}" method="POST" class="modal-content">
            @csrf
            <div class="modal-header"><h5 class="modal-title">Agregar / actualizar configuración</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <div class="modal-body">
                <div class="form-group"><label>Clave</label><input type="text" name="clave" class="form-control" placeholder="ej. checkin_hora" required></div>
                <div class="form-group"><label>Valor</label><input type="text" name="valor" class="form-control" required></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button><button class="btn btn-primary">Guardar</button></div>
        </form>
    </div>
</div>
@foreach($configuraciones as $config)
<div class="modal fade" id="modal-editar-config-{{ $loop->index }}">
    <div class="modal-dialog">
        <form action="{{ route('admin.configuracion.guardar') }}" method="POST" class="modal-content">
            @csrf
            <div class="modal-header"><h5 class="modal-title">Editar «{{ $config->clave }}»</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <div class="modal-body">
                <input type="hidden" name="clave" value="{{ $config->clave }}">
                <div class="form-group"><label>Valor</label><input type="text" name="valor" class="form-control" value="{{ $config->valor }}" required></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button><button class="btn btn-primary">Guardar</button></div>
        </form>
    </div>
</div>
@endforeach

<div class="modal fade" id="modal-nueva-fecha">
    <div class="modal-dialog">
        <form action="{{ route('admin.fechas-bloqueadas.store') }}" method="POST" class="modal-content">
            @csrf
            <div class="modal-header"><h5 class="modal-title">Bloquear una fecha</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <div class="modal-body">
                <div class="form-group"><label>Fecha</label><input type="date" name="fecha" class="form-control" required></div>
                <div class="form-group"><label>Motivo</label><input type="text" name="motivo" class="form-control" placeholder="ej. mantenimiento, evento privado"></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button><button class="btn btn-primary">Guardar</button></div>
        </form>
    </div>
</div>
@endsection
