<div class="modal-header">
    <h5 class="modal-title">{{ $domo ? 'Editar domo' : 'Nuevo domo' }}</h5>
    <button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body">
    <div class="form-group">
        <label>Clase</label>
        <select name="clase" class="form-control" required>
            <option value="">Selecciona una clase</option>
            @foreach($clases as $clase)
                <option value="{{ $clase->id }}" @selected($domo && $domo->clase == $clase->id)>{{ $clase->nombre }}</option>
            @endforeach
        </select>
    </div>
    <div class="form-group">
        <label>Para quién (texto libre)</label>
        <input type="text" name="opcion" class="form-control" value="{{ $domo->opcion ?? '' }}" placeholder="ej. familia, pareja, no mascotas">
    </div>
    <div class="form-group">
        <label>Capacidad máxima</label>
        <input type="number" min="1" name="capacidad_max" class="form-control" value="{{ $domo->capacidad_max ?? '' }}" required>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
    <button type="submit" class="btn btn-primary">Guardar</button>
</div>
