@extends('layouts.admin')

@section('titulo', 'Domos y clases de domo')

@section('contenido')
<div class="row">
    <div class="col-md-5">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title">Clases de domo</h3>
                @if(auth()->user()->hasPermiso('domos.crear'))
                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-crear-clase"><i class="fas fa-plus"></i></button>
                @endif
            </div>
            <div class="card-body p-0">
                <table class="table table-striped mb-0">
                    <thead><tr><th>#</th><th>Nombre</th><th></th></tr></thead>
                    <tbody>
                    @foreach($clases as $clase)
                        <tr>
                            <td>{{ $clase->id }}</td>
                            <td>{{ $clase->nombre }}</td>
                            <td class="text-right">
                                @if(auth()->user()->hasPermiso('domos.editar'))
                                <button class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal-editar-clase-{{ $clase->id }}"><i class="fas fa-pen"></i></button>
                                @endif
                                @if(auth()->user()->hasPermiso('domos.eliminar'))
                                <form action="{{ route('admin.clases-domo.destroy', $clase) }}" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar esta clase de domo?');">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></button>
                                </form>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-7">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title">Domos (unidades)</h3>
                @if(auth()->user()->hasPermiso('domos.crear'))
                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-crear-domo"><i class="fas fa-plus"></i> Nuevo domo</button>
                @endif
            </div>
            <div class="card-body">
                <table class="table table-bordered table-striped tabla-datos">
                    <thead><tr><th>#</th><th>Clase</th><th>Para quién</th><th>Capacidad</th><th style="width:90px">Acciones</th></tr></thead>
                    <tbody>
                    @foreach($domos as $domo)
                        <tr>
                            <td>{{ $domo->id }}</td>
                            <td>{{ $domo->claseDomo->nombre ?? '—' }}</td>
                            <td>{{ $domo->opcion }}</td>
                            <td>{{ $domo->capacidad_max }}</td>
                            <td>
                                @if(auth()->user()->hasPermiso('domos.editar'))
                                <button class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal-editar-domo-{{ $domo->id }}"><i class="fas fa-pen"></i></button>
                                @endif
                                @if(auth()->user()->hasPermiso('domos.eliminar'))
                                <form action="{{ route('admin.domos.destroy', $domo) }}" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar este domo?');">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></button>
                                </form>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

{{-- Modales de clase de domo --}}
<div class="modal fade" id="modal-crear-clase">
    <div class="modal-dialog">
        <form action="{{ route('admin.clases-domo.store') }}" method="POST" class="modal-content">
            @csrf
            <div class="modal-header"><h5 class="modal-title">Nueva clase de domo</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <div class="modal-body"><div class="form-group"><label>Nombre</label><input type="text" name="nombre" class="form-control" required></div></div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button><button class="btn btn-primary">Guardar</button></div>
        </form>
    </div>
</div>
@foreach($clases as $clase)
<div class="modal fade" id="modal-editar-clase-{{ $clase->id }}">
    <div class="modal-dialog">
        <form action="{{ route('admin.clases-domo.update', $clase) }}" method="POST" class="modal-content">
            @csrf @method('PUT')
            <div class="modal-header"><h5 class="modal-title">Editar clase de domo</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <div class="modal-body"><div class="form-group"><label>Nombre</label><input type="text" name="nombre" class="form-control" value="{{ $clase->nombre }}" required></div></div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button><button class="btn btn-primary">Guardar</button></div>
        </form>
    </div>
</div>
@endforeach

{{-- Modales de domo --}}
<div class="modal fade" id="modal-crear-domo">
    <div class="modal-dialog">
        <form action="{{ route('admin.domos.store') }}" method="POST" class="modal-content">
            @csrf
            @include('admin.domos._campos', ['domo' => null, 'clases' => $clases])
        </form>
    </div>
</div>
@foreach($domos as $domo)
<div class="modal fade" id="modal-editar-domo-{{ $domo->id }}">
    <div class="modal-dialog">
        <form action="{{ route('admin.domos.update', $domo) }}" method="POST" class="modal-content">
            @csrf @method('PUT')
            @include('admin.domos._campos', ['domo' => $domo, 'clases' => $clases])
        </form>
    </div>
</div>
@endforeach
@endsection
