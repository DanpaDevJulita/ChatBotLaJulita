{{-- Campos compartidos entre el modal de crear y cada modal de editar. $plan es null al crear. --}}
<div class="modal-header">
    <h5 class="modal-title">{{ $plan ? 'Editar plan' : 'Nuevo plan' }}</h5>
    <button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body">
    <div class="form-group">
        <label>Nombre</label>
        <input type="text" name="nombre" class="form-control" value="{{ $plan->nombre ?? '' }}" required>
    </div>
    <div class="form-group">
        <label>Descripción</label>
        <textarea name="descripcion" class="form-control" rows="4">{{ $plan->descripcion ?? '' }}</textarea>
        <small class="text-muted">No escribas precios acá: siempre se leen de los campos de precio de abajo, nunca del texto libre.</small>
    </div>
    <div class="form-row">
        <div class="form-group col-md-4">
            <label>Precio entre semana</label>
            <input type="number" step="1000" min="0" name="precio_entre_semana" class="form-control" value="{{ $plan->precio_entre_semana ?? '' }}">
        </div>
        <div class="form-group col-md-4">
            <label>Precio fin de semana</label>
            <input type="number" step="1000" min="0" name="precio_fin_de_semana" class="form-control" value="{{ $plan->precio_fin_de_semana ?? '' }}">
        </div>
        <div class="form-group col-md-4">
            <label>Precio puente/festivo</label>
            <input type="number" step="1000" min="0" name="precio_fin_de_semana_puente" class="form-control" value="{{ $plan->precio_fin_de_semana_puente ?? '' }}">
        </div>
    </div>
    <div class="form-group">
        <label>Domos que aplican a este plan</label>
        <select name="domos_id[]" class="form-control" multiple size="5">
            @foreach($domos as $domo)
                <option value="{{ $domo->id }}" @selected($plan && in_array($domo->id, $plan->domos_id ?? []))>
                    #{{ $domo->id }} — {{ $domo->claseDomo->nombre ?? 'Sin clase' }} ({{ $domo->opcion }}, hasta {{ $domo->capacidad_max }} pers.)
                </option>
            @endforeach
        </select>
        <small class="text-muted">Ctrl/Cmd + clic para seleccionar varios.</small>
    </div>
    <div class="form-group">
        <label>Link del video (URL directa .mp4, de preferencia)</label>
        <input type="url" name="link_video" class="form-control" value="{{ $plan->link_video ?? '' }}">
    </div>
    <div class="form-check">
        <input type="checkbox" name="activo" value="1" class="form-check-input" id="activo-plan-{{ $plan->id ?? 'nuevo' }}" @checked($plan ? $plan->activo : true)>
        <label class="form-check-label" for="activo-plan-{{ $plan->id ?? 'nuevo' }}">Plan activo (visible para el bot)</label>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
    <button type="submit" class="btn btn-primary">Guardar</button>
</div>
