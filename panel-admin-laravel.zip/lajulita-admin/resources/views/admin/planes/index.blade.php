@extends('layouts.admin')

@section('titulo', 'Planes')

@section('contenido')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">Planes</h3>
        @if(auth()->user()->hasPermiso('planes.crear'))
        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-crear-plan">
            <i class="fas fa-plus"></i> Nuevo plan
        </button>
        @endif
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped tabla-datos">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nombre</th>
                    <th>Entre semana</th>
                    <th>Fin de semana</th>
                    <th>Puente/festivo</th>
                    <th>Domos</th>
                    <th>Estado</th>
                    <th style="width:110px">Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach($planes as $plan)
                <tr>
                    <td>{{ $plan->id }}</td>
                    <td>{{ $plan->nombre }}</td>
                    <td>{{ $plan->precio_entre_semana !== null ? '$'.number_format($plan->precio_entre_semana, 0, ',', '.') : '—' }}</td>
                    <td>{{ $plan->precio_fin_de_semana !== null ? '$'.number_format($plan->precio_fin_de_semana, 0, ',', '.') : '—' }}</td>
                    <td>{{ $plan->precio_fin_de_semana_puente !== null ? '$'.number_format($plan->precio_fin_de_semana_puente, 0, ',', '.') : '—' }}</td>
                    <td>
                        @foreach($domos->whereIn('id', $plan->domos_id) as $domo)
                            <span class="badge badge-info">#{{ $domo->id }} {{ $domo->claseDomo->nombre ?? '' }}</span>
                        @endforeach
                    </td>
                    <td>
                        @if($plan->activo)
                            <span class="badge badge-success">Activo</span>
                        @else
                            <span class="badge badge-secondary">Inactivo</span>
                        @endif
                    </td>
                    <td>
                        @if(auth()->user()->hasPermiso('planes.editar'))
                        <button class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal-editar-plan-{{ $plan->id }}"><i class="fas fa-pen"></i></button>
                        @endif
                        @if(auth()->user()->hasPermiso('planes.eliminar'))
                        <form action="{{ route('admin.planes.destroy', $plan) }}" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar el plan «{{ $plan->nombre }}»? Esta acción no se puede deshacer.');">
                            @csrf @method('DELETE')
                            <button class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></button>
                        </form>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

{{-- Modal: crear plan --}}
<div class="modal fade" id="modal-crear-plan">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.planes.store') }}" method="POST" class="modal-content">
            @csrf
            @include('admin.planes._campos', ['plan' => null, 'domos' => $domos])
        </form>
    </div>
</div>

{{-- Modal: editar cada plan --}}
@foreach($planes as $plan)
<div class="modal fade" id="modal-editar-plan-{{ $plan->id }}">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.planes.update', $plan) }}" method="POST" class="modal-content">
            @csrf @method('PUT')
            @include('admin.planes._campos', ['plan' => $plan, 'domos' => $domos])
        </form>
    </div>
</div>
@endforeach
@endsection
