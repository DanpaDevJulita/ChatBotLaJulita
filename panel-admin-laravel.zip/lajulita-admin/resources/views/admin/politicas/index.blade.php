@extends('layouts.admin')

@section('titulo', 'Políticas')

@section('contenido')
<div class="alert alert-info">
    <i class="fas fa-circle-info"></i> Lo que se guarde acá es lo que el bot le manda <strong>tal cual, palabra por palabra</strong> al cliente por WhatsApp. La negrita se escribe con un solo asterisco (<code>*así*</code>), nunca con dos. El bot relee estos textos cada 30 segundos como máximo.
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">Políticas y textos oficiales</h3>
        @if(auth()->user()->hasPermiso('politicas.crear'))
        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-crear-politica"><i class="fas fa-plus"></i> Nueva política</button>
        @endif
    </div>
    <div class="card-body">
        @foreach($politicas as $politica)
        <div class="card card-outline {{ $politica->activo ? 'card-success' : 'card-secondary' }} mb-3">
            <div class="card-header">
                <h3 class="card-title">{{ $politica->titulo ?? $politica->clave }}
                    <span class="badge {{ $politica->activo ? 'badge-success' : 'badge-secondary' }}">{{ $politica->activo ? 'Activa' : 'Inactiva' }}</span>
                </h3>
                <div class="card-tools">
                    <code class="mr-2">{{ $politica->clave }}</code>
                    @if(auth()->user()->hasPermiso('politicas.editar'))
                    <button class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal-editar-politica-{{ $politica->clave }}"><i class="fas fa-pen"></i> Editar</button>
                    @endif
                </div>
            </div>
            <div class="card-body">
                <pre class="mb-0" style="white-space: pre-wrap; font-family: inherit;">{{ $politica->contenido }}</pre>
            </div>
        </div>
        @endforeach
    </div>
</div>

<div class="modal fade" id="modal-crear-politica">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.politicas.store') }}" method="POST" class="modal-content">
            @csrf
            @include('admin.politicas._campos', ['politica' => null])
        </form>
    </div>
</div>
@foreach($politicas as $politica)
<div class="modal fade" id="modal-editar-politica-{{ $politica->clave }}">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.politicas.update', $politica) }}" method="POST" class="modal-content">
            @csrf @method('PUT')
            @include('admin.politicas._campos', ['politica' => $politica])
        </form>
    </div>
</div>
@endforeach
@endsection
