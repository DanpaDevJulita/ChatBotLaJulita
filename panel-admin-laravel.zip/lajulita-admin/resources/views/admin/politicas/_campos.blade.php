<div class="modal-header">
    <h5 class="modal-title">{{ $politica ? 'Editar política' : 'Nueva política' }}</h5>
    <button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body">
    @if(! $politica)
    <div class="form-group">
        <label>Clave (identificador interno, sin espacios)</label>
        <input type="text" name="clave" class="form-control" placeholder="ej. politica_mascotas" required>
    </div>
    @endif
    <div class="form-group">
        <label>Título</label>
        <input type="text" name="titulo" class="form-control" value="{{ $politica->titulo ?? '' }}">
    </div>
    <div class="form-group">
        <label>Contenido (formato WhatsApp: *negrita* con un asterisco)</label>
        <textarea name="contenido" class="form-control" rows="10" required>{{ $politica->contenido ?? '' }}</textarea>
    </div>
    <div class="form-check">
        <input type="checkbox" name="activo" value="1" class="form-check-input" id="activo-politica-{{ $politica->clave ?? 'nueva' }}" @checked($politica ? $politica->activo : true)>
        <label class="form-check-label" for="activo-politica-{{ $politica->clave ?? 'nueva' }}">Política activa (el bot la usa)</label>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
    <button type="submit" class="btn btn-primary">Guardar</button>
</div>
