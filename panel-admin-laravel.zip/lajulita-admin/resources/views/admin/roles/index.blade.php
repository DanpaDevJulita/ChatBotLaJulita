@extends('layouts.admin')

@section('titulo', 'Roles y permisos')

@section('contenido')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">Roles</h3>
        @if(auth()->user()->hasPermiso('roles.crear'))
        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-crear-rol"><i class="fas fa-plus"></i> Nuevo rol</button>
        @endif
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead><tr><th>Rol</th><th>Descripción</th><th>Permisos</th><th style="width:90px">Acciones</th></tr></thead>
            <tbody>
            @foreach($roles as $rol)
                <tr>
                    <td><strong>{{ $rol->nombre }}</strong></td>
                    <td>{{ $rol->descripcion }}</td>
                    <td>{{ $rol->permisos->count() }} de {{ $permisosPorModulo->flatten()->count() }}</td>
                    <td>
                        @if(auth()->user()->hasPermiso('roles.editar'))
                        <button class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal-editar-rol-{{ $rol->id }}"><i class="fas fa-pen"></i></button>
                        @endif
                        @if(auth()->user()->hasPermiso('roles.eliminar'))
                        <form action="{{ route('admin.roles.destroy', $rol) }}" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar este rol?');">
                            @csrf @method('DELETE')
                            <button class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></button>
                        </form>
                        @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="modal-crear-rol">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.roles.store') }}" method="POST" class="modal-content">
            @csrf
            @include('admin.roles._campos', ['rol' => null, 'permisosPorModulo' => $permisosPorModulo])
        </form>
    </div>
</div>
@foreach($roles as $rol)
<div class="modal fade" id="modal-editar-rol-{{ $rol->id }}">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.roles.update', $rol) }}" method="POST" class="modal-content">
            @csrf @method('PUT')
            @include('admin.roles._campos', ['rol' => $rol, 'permisosPorModulo' => $permisosPorModulo])
        </form>
    </div>
</div>
@endforeach
@endsection
