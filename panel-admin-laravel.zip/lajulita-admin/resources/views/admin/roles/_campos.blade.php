@php $permisosDelRol = $rol ? $rol->permisos->pluck('id')->all() : []; @endphp
<div class="modal-header">
    <h5 class="modal-title">{{ $rol ? 'Editar rol' : 'Nuevo rol' }}</h5>
    <button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body">
    <div class="form-row">
        <div class="form-group col-md-5">
            <label>Nombre del rol</label>
            <input type="text" name="nombre" class="form-control" value="{{ $rol->nombre ?? '' }}" required>
        </div>
        <div class="form-group col-md-7">
            <label>Descripción</label>
            <input type="text" name="descripcion" class="form-control" value="{{ $rol->descripcion ?? '' }}">
        </div>
    </div>

    <label>Permisos</label>
    <div class="row">
        @foreach($permisosPorModulo as $modulo => $permisos)
        <div class="col-md-4 mb-3">
            <div class="card card-body p-2">
                <strong class="text-capitalize mb-1">{{ str_replace('_', ' ', $modulo) }}</strong>
                @foreach($permisos as $permiso)
                    <div class="form-check">
                        <input type="checkbox" name="permisos[]" value="{{ $permiso->id }}" class="form-check-input" id="permiso-{{ $rol->id ?? 'nuevo' }}-{{ $permiso->id }}" @checked(in_array($permiso->id, $permisosDelRol))>
                        <label class="form-check-label" for="permiso-{{ $rol->id ?? 'nuevo' }}-{{ $permiso->id }}">{{ $permiso->etiqueta }}</label>
                    </div>
                @endforeach
            </div>
        </div>
        @endforeach
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
    <button type="submit" class="btn btn-primary">Guardar</button>
</div>
