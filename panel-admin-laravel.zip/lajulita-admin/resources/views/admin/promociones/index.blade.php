@extends('layouts.admin')

@section('titulo', 'Promociones')

@section('contenido')
<div class="alert alert-warning">
    <i class="fas fa-triangle-exclamation"></i> Esta tabla es nueva: hoy el bot <strong>todavía no la usa</strong> para calcular precios. Sirve para que el equipo comercial lleve el control de las promociones vigentes desde un solo lugar; conectarla a la lógica de ventas del bot es un paso futuro.
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">Promociones</h3>
        @if(auth()->user()->hasPermiso('promociones.crear'))
        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-crear-promo"><i class="fas fa-plus"></i> Nueva promoción</button>
        @endif
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped tabla-datos">
            <thead>
                <tr><th>#</th><th>Nombre</th><th>Descuento</th><th>Código</th><th>Plan</th><th>Vigencia</th><th>Estado</th><th style="width:90px">Acciones</th></tr>
            </thead>
            <tbody>
            @foreach($promociones as $promo)
                <tr>
                    <td>{{ $promo->id }}</td>
                    <td>{{ $promo->nombre }}</td>
                    <td>{{ $promo->tipo === 'porcentaje' ? number_format($promo->valor, 0).'%' : '$'.number_format($promo->valor, 0, ',', '.') }}</td>
                    <td>{{ $promo->codigo ?? '—' }}</td>
                    <td>{{ $promo->plan->nombre ?? 'Todos' }}</td>
                    <td>
                        {{ $promo->fecha_inicio?->format('d/m/Y') ?? 'Desde siempre' }}
                        —
                        {{ $promo->fecha_fin?->format('d/m/Y') ?? 'Sin fin' }}
                    </td>
                    <td>
                        @if($promo->vigente())
                            <span class="badge badge-success">Vigente</span>
                        @elseif($promo->activo)
                            <span class="badge badge-warning">Activa (fuera de fecha)</span>
                        @else
                            <span class="badge badge-secondary">Inactiva</span>
                        @endif
                    </td>
                    <td>
                        @if(auth()->user()->hasPermiso('promociones.editar'))
                        <button class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal-editar-promo-{{ $promo->id }}"><i class="fas fa-pen"></i></button>
                        @endif
                        @if(auth()->user()->hasPermiso('promociones.eliminar'))
                        <form action="{{ route('admin.promociones.destroy', $promo) }}" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar esta promoción?');">
                            @csrf @method('DELETE')
                            <button class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></button>
                        </form>
                        @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="modal-crear-promo">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.promociones.store') }}" method="POST" class="modal-content">
            @csrf
            @include('admin.promociones._campos', ['promo' => null, 'planes' => $planes])
        </form>
    </div>
</div>
@foreach($promociones as $promo)
<div class="modal fade" id="modal-editar-promo-{{ $promo->id }}">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.promociones.update', $promo) }}" method="POST" class="modal-content">
            @csrf @method('PUT')
            @include('admin.promociones._campos', ['promo' => $promo, 'planes' => $planes])
        </form>
    </div>
</div>
@endforeach
@endsection
