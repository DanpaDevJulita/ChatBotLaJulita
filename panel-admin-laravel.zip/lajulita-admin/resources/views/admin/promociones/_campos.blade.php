<div class="modal-header">
    <h5 class="modal-title">{{ $promo ? 'Editar promoción' : 'Nueva promoción' }}</h5>
    <button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body">
    <div class="form-group">
        <label>Nombre</label>
        <input type="text" name="nombre" class="form-control" value="{{ $promo->nombre ?? '' }}" required>
    </div>
    <div class="form-group">
        <label>Descripción</label>
        <textarea name="descripcion" class="form-control" rows="2">{{ $promo->descripcion ?? '' }}</textarea>
    </div>
    <div class="form-row">
        <div class="form-group col-md-4">
            <label>Tipo de descuento</label>
            <select name="tipo" class="form-control" required>
                <option value="porcentaje" @selected(!$promo || $promo->tipo === 'porcentaje')>Porcentaje (%)</option>
                <option value="monto_fijo" @selected($promo && $promo->tipo === 'monto_fijo')>Monto fijo ($)</option>
            </select>
        </div>
        <div class="form-group col-md-4">
            <label>Valor</label>
            <input type="number" step="1" min="0" name="valor" class="form-control" value="{{ $promo->valor ?? '' }}" required>
        </div>
        <div class="form-group col-md-4">
            <label>Código (opcional)</label>
            <input type="text" name="codigo" class="form-control" value="{{ $promo->codigo ?? '' }}" placeholder="ej. VERANO2026">
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-4">
            <label>Plan específico (vacío = todos)</label>
            <select name="plan_id" class="form-control">
                <option value="">Todos los planes</option>
                @foreach($planes as $plan)
                    <option value="{{ $plan->id }}" @selected($promo && $promo->plan_id == $plan->id)>{{ $plan->nombre }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group col-md-4">
            <label>Fecha de inicio</label>
            <input type="date" name="fecha_inicio" class="form-control" value="{{ optional($promo?->fecha_inicio)->format('Y-m-d') }}">
        </div>
        <div class="form-group col-md-4">
            <label>Fecha de fin</label>
            <input type="date" name="fecha_fin" class="form-control" value="{{ optional($promo?->fecha_fin)->format('Y-m-d') }}">
        </div>
    </div>
    <div class="form-check">
        <input type="checkbox" name="activo" value="1" class="form-check-input" id="activo-promo-{{ $promo->id ?? 'nueva' }}" @checked($promo ? $promo->activo : true)>
        <label class="form-check-label" for="activo-promo-{{ $promo->id ?? 'nueva' }}">Promoción activa</label>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
    <button type="submit" class="btn btn-primary">Guardar</button>
</div>
