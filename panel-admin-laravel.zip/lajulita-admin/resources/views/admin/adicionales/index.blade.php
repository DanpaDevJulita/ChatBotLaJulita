@extends('layouts.admin')

@section('titulo', 'Adicionales')

@section('contenido')
<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title">Tipos de adicional</h3>
                @if(auth()->user()->hasPermiso('adicionales.crear'))
                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-crear-tipo"><i class="fas fa-plus"></i></button>
                @endif
            </div>
            <div class="card-body p-0">
                <table class="table table-striped mb-0">
                    <thead><tr><th>#</th><th>Nombre</th><th></th></tr></thead>
                    <tbody>
                    @foreach($tipos as $tipo)
                        <tr>
                            <td>{{ $tipo->id }}</td>
                            <td>{{ $tipo->nombre }}</td>
                            <td class="text-right">
                                @if(auth()->user()->hasPermiso('adicionales.editar'))
                                <button class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal-editar-tipo-{{ $tipo->id }}"><i class="fas fa-pen"></i></button>
                                @endif
                                @if(auth()->user()->hasPermiso('adicionales.eliminar'))
                                <form action="{{ route('admin.tipos-adicional.destroy', $tipo) }}" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar este tipo?');">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></button>
                                </form>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title">Adicionales</h3>
                @if(auth()->user()->hasPermiso('adicionales.crear'))
                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-crear-adicional"><i class="fas fa-plus"></i> Nuevo adicional</button>
                @endif
            </div>
            <div class="card-body">
                <table class="table table-bordered table-striped tabla-datos">
                    <thead><tr><th>#</th><th>Nombre</th><th>Tipo</th><th>Precio</th><th>Estado</th><th style="width:90px">Acciones</th></tr></thead>
                    <tbody>
                    @foreach($adicionales as $adicional)
                        <tr>
                            <td>{{ $adicional->id }}</td>
                            <td>{{ $adicional->nombre }}</td>
                            <td>{{ $adicional->tipoAdicional->nombre ?? '—' }}</td>
                            <td>{{ $adicional->precio !== null ? '$'.number_format($adicional->precio, 0, ',', '.') : '—' }}</td>
                            <td>
                                @if($adicional->estado)
                                    <span class="badge badge-success">Activo</span>
                                @else
                                    <span class="badge badge-secondary">Inactivo</span>
                                @endif
                            </td>
                            <td>
                                @if(auth()->user()->hasPermiso('adicionales.editar'))
                                <button class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal-editar-adicional-{{ $adicional->id }}"><i class="fas fa-pen"></i></button>
                                @endif
                                @if(auth()->user()->hasPermiso('adicionales.eliminar'))
                                <form action="{{ route('admin.adicionales.destroy', $adicional) }}" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar este adicional?');">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></button>
                                </form>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

{{-- Tipos --}}
<div class="modal fade" id="modal-crear-tipo">
    <div class="modal-dialog">
        <form action="{{ route('admin.tipos-adicional.store') }}" method="POST" class="modal-content">
            @csrf
            <div class="modal-header"><h5 class="modal-title">Nuevo tipo de adicional</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <div class="modal-body"><div class="form-group"><label>Nombre</label><input type="text" name="nombre" class="form-control" required></div></div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button><button class="btn btn-primary">Guardar</button></div>
        </form>
    </div>
</div>
@foreach($tipos as $tipo)
<div class="modal fade" id="modal-editar-tipo-{{ $tipo->id }}">
    <div class="modal-dialog">
        <form action="{{ route('admin.tipos-adicional.update', $tipo) }}" method="POST" class="modal-content">
            @csrf @method('PUT')
            <div class="modal-header"><h5 class="modal-title">Editar tipo de adicional</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <div class="modal-body"><div class="form-group"><label>Nombre</label><input type="text" name="nombre" class="form-control" value="{{ $tipo->nombre }}" required></div></div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button><button class="btn btn-primary">Guardar</button></div>
        </form>
    </div>
</div>
@endforeach

{{-- Adicionales --}}
<div class="modal fade" id="modal-crear-adicional">
    <div class="modal-dialog">
        <form action="{{ route('admin.adicionales.store') }}" method="POST" class="modal-content">
            @csrf
            @include('admin.adicionales._campos', ['adicional' => null, 'tipos' => $tipos])
        </form>
    </div>
</div>
@foreach($adicionales as $adicional)
<div class="modal fade" id="modal-editar-adicional-{{ $adicional->id }}">
    <div class="modal-dialog">
        <form action="{{ route('admin.adicionales.update', $adicional) }}" method="POST" class="modal-content">
            @csrf @method('PUT')
            @include('admin.adicionales._campos', ['adicional' => $adicional, 'tipos' => $tipos])
        </form>
    </div>
</div>
@endforeach
@endsection
