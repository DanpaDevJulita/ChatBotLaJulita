<div class="modal-header">
    <h5 class="modal-title">{{ $adicional ? 'Editar adicional' : 'Nuevo adicional' }}</h5>
    <button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body">
    <div class="form-group">
        <label>Nombre</label>
        <input type="text" name="nombre" class="form-control" value="{{ $adicional->nombre ?? '' }}" required>
    </div>
    <div class="form-group">
        <label>Descripción</label>
        <textarea name="descripcion" class="form-control" rows="3">{{ $adicional->descripcion ?? '' }}</textarea>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label>Tipo</label>
            <select name="tipo_adicional_id" class="form-control" required>
                <option value="">Selecciona un tipo</option>
                @foreach($tipos as $tipo)
                    <option value="{{ $tipo->id }}" @selected($adicional && $adicional->tipo_adicional_id == $tipo->id)>{{ $tipo->nombre }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group col-md-6">
            <label>Precio</label>
            <input type="number" step="1000" min="0" name="precio" class="form-control" value="{{ $adicional->precio ?? '' }}">
        </div>
    </div>
    <div class="form-check">
        <input type="checkbox" name="estado" value="1" class="form-check-input" id="estado-adicional-{{ $adicional->id ?? 'nuevo' }}" @checked($adicional ? $adicional->estado : true)>
        <label class="form-check-label" for="estado-adicional-{{ $adicional->id ?? 'nuevo' }}">Adicional activo (visible para el bot)</label>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
    <button type="submit" class="btn btn-primary">Guardar</button>
</div>
