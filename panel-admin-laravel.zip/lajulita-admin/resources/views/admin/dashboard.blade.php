@extends('layouts.admin')

@section('titulo', 'Dashboard')

@section('contenido')
<div class="row">
    <div class="col-lg-3 col-6">
        <div class="small-box bg-success">
            <div class="inner"><h3>{{ $tarjetas['planes_activos'] }}</h3><p>Planes activos</p></div>
            <div class="icon"><i class="fas fa-campground"></i></div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-info">
            <div class="inner"><h3>{{ $tarjetas['domos'] }}</h3><p>Domos registrados</p></div>
            <div class="icon"><i class="fas fa-house-chimney"></i></div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-warning">
            <div class="inner"><h3>{{ $tarjetas['adicionales_activos'] }}</h3><p>Adicionales activos</p></div>
            <div class="icon"><i class="fas fa-plus"></i></div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-danger">
            <div class="inner"><h3>{{ $tarjetas['promociones_vigentes'] }}</h3><p>Promociones vigentes</p></div>
            <div class="icon"><i class="fas fa-tags"></i></div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-secondary">
            <div class="inner"><h3>{{ $tarjetas['recargos_activos'] }}</h3><p>Recargos activos (niños/mascotas)</p></div>
            <div class="icon"><i class="fas fa-child-reaching"></i></div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-secondary">
            <div class="inner"><h3>{{ $tarjetas['politicas'] }}</h3><p>Políticas cargadas</p></div>
            <div class="icon"><i class="fas fa-file-contract"></i></div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-secondary">
            <div class="inner"><h3>{{ $tarjetas['faq'] }}</h3><p>Preguntas frecuentes</p></div>
            <div class="icon"><i class="fas fa-circle-question"></i></div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">Últimos cambios en el catálogo</h3>
    </div>
    <div class="card-body p-0">
        <table class="table table-striped mb-0">
            <thead>
                <tr><th>Fecha</th><th>Usuario</th><th>Módulo</th><th>Acción</th><th>Detalle</th></tr>
            </thead>
            <tbody>
                @forelse($ultimosCambios as $cambio)
                    <tr>
                        <td>{{ $cambio->created_at->format('d/m/Y H:i') }}</td>
                        <td>{{ $cambio->usuario->name ?? '—' }}</td>
                        <td><span class="badge badge-secondary">{{ $cambio->modulo }}</span></td>
                        <td>{{ ucfirst($cambio->accion) }}</td>
                        <td>{{ $cambio->descripcion }}</td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="text-center text-muted py-3">Todavía no hay cambios registrados.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
