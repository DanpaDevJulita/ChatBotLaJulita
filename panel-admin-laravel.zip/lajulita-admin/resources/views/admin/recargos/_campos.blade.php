<div class="modal-header">
    <h5 class="modal-title">{{ $recargo ? 'Editar recargo' : 'Nuevo recargo' }}</h5>
    <button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body">
    <div class="form-group">
        <label>Tipo</label>
        @php $idFormulario = 'tipo-recargo-'.($recargo->id ?? 'nuevo'); @endphp
        <select name="tipo" class="form-control" required id="{{ $idFormulario }}" onchange="document.getElementById('edades-{{ $recargo->id ?? 'nuevo' }}').style.display = this.value === 'nino' ? 'flex' : 'none'">
            <option value="nino" @selected(!$recargo || $recargo->tipo === 'nino')>Niño</option>
            <option value="mascota" @selected($recargo && $recargo->tipo === 'mascota')>Mascota</option>
        </select>
    </div>
    <div class="form-group">
        <label>Nombre (como se lo dice el bot al cliente)</label>
        <input type="text" name="nombre" class="form-control" value="{{ $recargo->nombre ?? '' }}" placeholder="ej. Niño de 3 a 5 años" required>
    </div>
    <div class="form-group">
        <label>Descripción / condiciones</label>
        <input type="text" name="descripcion" class="form-control" value="{{ $recargo->descripcion ?? '' }}" placeholder="ej. Valor por noche, adicional al plan">
    </div>
    <div class="form-row" id="edades-{{ $recargo->id ?? 'nuevo' }}" style="{{ (! $recargo || $recargo->tipo === 'nino') ? '' : 'display:none' }}">
        <div class="form-group col-md-6">
            <label>Edad mínima</label>
            <input type="number" min="0" name="edad_min" class="form-control" value="{{ $recargo->edad_min ?? '' }}">
        </div>
        <div class="form-group col-md-6">
            <label>Edad máxima (vacío = sin tope)</label>
            <input type="number" min="0" name="edad_max" class="form-control" value="{{ $recargo->edad_max ?? '' }}">
        </div>
    </div>
    <div class="form-group">
        <label>Precio</label>
        <input type="number" step="1000" min="0" name="precio" class="form-control" value="{{ $recargo->precio ?? '' }}" required>
    </div>
    <div class="form-group">
        <label>¿Aplica solo a un plan puntual?</label>
        <select name="plan_id" class="form-control">
            <option value="">Todos los planes</option>
            @foreach($planes as $plan)
                <option value="{{ $plan->id }}" @selected($recargo && $recargo->plan_id == $plan->id)>{{ $plan->nombre }}</option>
            @endforeach
        </select>
    </div>
    <div class="form-check">
        <input type="checkbox" name="activo" value="1" class="form-check-input" id="activo-recargo-{{ $recargo->id ?? 'nuevo' }}" @checked($recargo ? $recargo->activo : true)>
        <label class="form-check-label" for="activo-recargo-{{ $recargo->id ?? 'nuevo' }}">Recargo activo</label>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
    <button type="submit" class="btn btn-primary">Guardar</button>
</div>
