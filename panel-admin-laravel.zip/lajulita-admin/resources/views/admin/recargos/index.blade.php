@extends('layouts.admin')

@section('titulo', 'Niños y mascotas (recargos)')

@section('contenido')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">Recargos por niño (según edad) y por mascota</h3>
        @if(auth()->user()->hasPermiso('recargos.crear'))
        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-crear-recargo"><i class="fas fa-plus"></i> Nuevo recargo</button>
        @endif
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped tabla-datos">
            <thead>
                <tr><th>#</th><th>Tipo</th><th>Nombre</th><th>Rango de edad</th><th>Precio</th><th>Plan específico</th><th>Estado</th><th style="width:90px">Acciones</th></tr>
            </thead>
            <tbody>
            @foreach($recargos as $recargo)
                <tr>
                    <td>{{ $recargo->id }}</td>
                    <td>{{ $recargo->tipo === 'nino' ? 'Niño' : 'Mascota' }}</td>
                    <td>{{ $recargo->nombre }}</td>
                    <td>
                        @if($recargo->tipo === 'nino')
                            {{ $recargo->edad_min }}{{ $recargo->edad_max ? ' a '.$recargo->edad_max : ' en adelante' }} años
                        @else
                            —
                        @endif
                    </td>
                    <td>${{ number_format($recargo->precio, 0, ',', '.') }}</td>
                    <td>{{ $recargo->plan->nombre ?? 'Todos los planes' }}</td>
                    <td>
                        @if($recargo->activo)
                            <span class="badge badge-success">Activo</span>
                        @else
                            <span class="badge badge-secondary">Inactivo</span>
                        @endif
                    </td>
                    <td>
                        @if(auth()->user()->hasPermiso('recargos.editar'))
                        <button class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal-editar-recargo-{{ $recargo->id }}"><i class="fas fa-pen"></i></button>
                        @endif
                        @if(auth()->user()->hasPermiso('recargos.eliminar'))
                        <form action="{{ route('admin.recargos.destroy', $recargo) }}" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar este recargo?');">
                            @csrf @method('DELETE')
                            <button class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></button>
                        </form>
                        @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="modal-crear-recargo">
    <div class="modal-dialog">
        <form action="{{ route('admin.recargos.store') }}" method="POST" class="modal-content">
            @csrf
            @include('admin.recargos._campos', ['recargo' => null, 'planes' => $planes])
        </form>
    </div>
</div>
@foreach($recargos as $recargo)
<div class="modal fade" id="modal-editar-recargo-{{ $recargo->id }}">
    <div class="modal-dialog">
        <form action="{{ route('admin.recargos.update', $recargo) }}" method="POST" class="modal-content">
            @csrf @method('PUT')
            @include('admin.recargos._campos', ['recargo' => $recargo, 'planes' => $planes])
        </form>
    </div>
</div>
@endforeach
@endsection
