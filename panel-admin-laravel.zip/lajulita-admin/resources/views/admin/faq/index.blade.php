@extends('layouts.admin')

@section('titulo', 'Preguntas frecuentes')

@section('contenido')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">FAQ</h3>
        @if(auth()->user()->hasPermiso('faq.crear'))
        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-crear-faq"><i class="fas fa-plus"></i> Nueva pregunta</button>
        @endif
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped tabla-datos">
            <thead><tr><th>Tema</th><th>Pregunta ejemplo</th><th>Respuesta</th><th style="width:90px">Acciones</th></tr></thead>
            <tbody>
            @foreach($faqs as $faq)
                <tr>
                    <td><code>{{ $faq->tema }}</code></td>
                    <td>{{ $faq->pregunta_ejemplo }}</td>
                    <td>{{ \Illuminate\Support\Str::limit($faq->respuesta, 80) }}</td>
                    <td>
                        @if(auth()->user()->hasPermiso('faq.editar'))
                        <button class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal-editar-faq-{{ $loop->index }}"><i class="fas fa-pen"></i></button>
                        @endif
                        @if(auth()->user()->hasPermiso('faq.eliminar'))
                        <form action="{{ route('admin.faq.destroy', $faq) }}" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar esta pregunta frecuente?');">
                            @csrf @method('DELETE')
                            <button class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></button>
                        </form>
                        @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="modal-crear-faq">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.faq.store') }}" method="POST" class="modal-content">
            @csrf
            @include('admin.faq._campos', ['faq' => null])
        </form>
    </div>
</div>
@foreach($faqs as $faq)
<div class="modal fade" id="modal-editar-faq-{{ $loop->index }}">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('admin.faq.update', $faq) }}" method="POST" class="modal-content">
            @csrf @method('PUT')
            @include('admin.faq._campos', ['faq' => $faq])
        </form>
    </div>
</div>
@endforeach
@endsection
