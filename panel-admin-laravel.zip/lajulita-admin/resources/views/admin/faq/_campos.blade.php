<div class="modal-header">
    <h5 class="modal-title">{{ $faq ? 'Editar pregunta frecuente' : 'Nueva pregunta frecuente' }}</h5>
    <button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body">
    @if(! $faq)
    <div class="form-group">
        <label>Tema (identificador interno)</label>
        <input type="text" name="tema" class="form-control" placeholder="ej. horario_jacuzzi" required>
    </div>
    @endif
    <div class="form-group">
        <label>Pregunta de ejemplo</label>
        <input type="text" name="pregunta_ejemplo" class="form-control" value="{{ $faq->pregunta_ejemplo ?? '' }}" placeholder="ej. ¿A qué hora puedo usar el jacuzzi?">
    </div>
    <div class="form-group">
        <label>Respuesta</label>
        <textarea name="respuesta" class="form-control" rows="5" required>{{ $faq->respuesta ?? '' }}</textarea>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
    <button type="submit" class="btn btn-primary">Guardar</button>
</div>
