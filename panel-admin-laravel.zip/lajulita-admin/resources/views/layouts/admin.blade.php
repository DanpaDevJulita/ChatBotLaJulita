<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('titulo', 'Panel') · Panel La Julita</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    @stack('estilos')
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <i class="far fa-user mr-1"></i> {{ auth()->user()->name }}
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <span class="dropdown-item-text text-muted small">{{ auth()->user()->rol->nombre ?? 'Sin rol' }}</span>
                    <div class="dropdown-divider"></div>
                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button type="submit" class="dropdown-item">
                            <i class="fas fa-sign-out-alt mr-2"></i> Cerrar sesión
                        </button>
                    </form>
                </div>
            </li>
        </ul>
    </nav>

    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="{{ route('admin.dashboard') }}" class="brand-link">
            <span class="brand-text font-weight-light ml-2">🏕️ La Julita</span>
        </a>

        <div class="sidebar">
            <nav class="mt-2">
                @php $usuario = auth()->user(); @endphp
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">

                    <li class="nav-item">
                        <a href="{{ route('admin.dashboard') }}" class="nav-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-gauge-high"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>

                    @if($usuario->hasPermiso('planes.ver'))
                    <li class="nav-item">
                        <a href="{{ route('admin.planes.index') }}" class="nav-link {{ request()->routeIs('admin.planes.*') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-campground"></i>
                            <p>Planes</p>
                        </a>
                    </li>
                    @endif

                    @if($usuario->hasPermiso('domos.ver'))
                    <li class="nav-item">
                        <a href="{{ route('admin.domos.index') }}" class="nav-link {{ request()->routeIs('admin.domos.*') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-house-chimney"></i>
                            <p>Domos y clases</p>
                        </a>
                    </li>
                    @endif

                    @if($usuario->hasPermiso('adicionales.ver'))
                    <li class="nav-item">
                        <a href="{{ route('admin.adicionales.index') }}" class="nav-link {{ request()->routeIs('admin.adicionales.*') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-plus"></i>
                            <p>Adicionales</p>
                        </a>
                    </li>
                    @endif

                    @if($usuario->hasPermiso('recargos.ver'))
                    <li class="nav-item">
                        <a href="{{ route('admin.recargos.index') }}" class="nav-link {{ request()->routeIs('admin.recargos.*') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-child-reaching"></i>
                            <p>Niños y mascotas</p>
                        </a>
                    </li>
                    @endif

                    @if($usuario->hasPermiso('promociones.ver'))
                    <li class="nav-item">
                        <a href="{{ route('admin.promociones.index') }}" class="nav-link {{ request()->routeIs('admin.promociones.*') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-tags"></i>
                            <p>Promociones</p>
                        </a>
                    </li>
                    @endif

                    @if($usuario->hasPermiso('politicas.ver'))
                    <li class="nav-item">
                        <a href="{{ route('admin.politicas.index') }}" class="nav-link {{ request()->routeIs('admin.politicas.*') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-file-contract"></i>
                            <p>Políticas</p>
                        </a>
                    </li>
                    @endif

                    @if($usuario->hasPermiso('faq.ver'))
                    <li class="nav-item">
                        <a href="{{ route('admin.faq.index') }}" class="nav-link {{ request()->routeIs('admin.faq.*') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-circle-question"></i>
                            <p>Preguntas frecuentes</p>
                        </a>
                    </li>
                    @endif

                    @if($usuario->hasPermiso('configuracion.ver'))
                    <li class="nav-item">
                        <a href="{{ route('admin.configuracion.index') }}" class="nav-link {{ request()->routeIs('admin.configuracion.*') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-gears"></i>
                            <p>Horarios y fechas bloqueadas</p>
                        </a>
                    </li>
                    @endif

                    @if($usuario->hasPermiso('usuarios.ver') || $usuario->hasPermiso('roles.ver'))
                    <li class="nav-header">ADMINISTRACIÓN</li>
                    @endif

                    @if($usuario->hasPermiso('usuarios.ver'))
                    <li class="nav-item">
                        <a href="{{ route('admin.usuarios.index') }}" class="nav-link {{ request()->routeIs('admin.usuarios.*') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-users"></i>
                            <p>Usuarios</p>
                        </a>
                    </li>
                    @endif

                    @if($usuario->hasPermiso('roles.ver'))
                    <li class="nav-item">
                        <a href="{{ route('admin.roles.index') }}" class="nav-link {{ request()->routeIs('admin.roles.*') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-user-shield"></i>
                            <p>Roles y permisos</p>
                        </a>
                    </li>
                    @endif
                </ul>
            </nav>
        </div>
    </aside>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">@yield('titulo')</h1>
                    </div>
                </div>
            </div>
        </div>

        <section class="content">
            <div class="container-fluid">
                @if(session('ok'))
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        {{ session('ok') }}
                    </div>
                @endif
                @if(session('error'))
                    <div class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        {{ session('error') }}
                    </div>
                @endif
                @if($errors->any())
                    <div class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <strong>Revisa estos campos:</strong>
                        <ul class="mb-0">
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                @yield('contenido')
            </div>
        </section>
    </div>

    <footer class="main-footer">
        <strong>La Julita</strong> — Panel de administración del catálogo del bot.
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/plugins/jquery/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(function () {
        $('.tabla-datos').each(function () {
            $(this).DataTable({
                language: {
                    url: 'https://cdn.jsdelivr.net/npm/datatables.net-plugins@1.13.6/i18n/es-ES.json',
                },
                paging: true,
                lengthChange: true,
                searching: true,
                ordering: true,
                info: true,
            });
        });

        @if(session('abrirModal'))
            $('#{{ session('abrirModal') }}').modal('show');
        @endif
    });
</script>
@stack('scripts')
</body>
</html>
