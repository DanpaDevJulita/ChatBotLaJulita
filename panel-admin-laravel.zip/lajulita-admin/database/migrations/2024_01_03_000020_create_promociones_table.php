<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

/**
 * Tabla NUEVA (no existía en el bot). Ver App\Models\Promocion para el detalle de qué guarda
 * y qué falta por hacer para que el bot la use.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('promociones')) {
            return;
        }

        Schema::create('promociones', function (Blueprint $table) {
            $table->id();
            $table->string('nombre');
            $table->text('descripcion')->nullable();
            $table->string('tipo'); // 'porcentaje' | 'monto_fijo'
            $table->decimal('valor', 12, 2);
            $table->string('codigo')->nullable()->unique();
            // NULL = aplica a todos los planes (mismo patrón que recargos.plan_id).
            $table->foreignId('plan_id')->nullable()->constrained('planes')->cascadeOnDelete();
            $table->date('fecha_inicio')->nullable();
            $table->date('fecha_fin')->nullable();
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        DB::statement("alter table promociones add constraint promociones_tipo_check check (tipo in ('porcentaje','monto_fijo'))");
        DB::statement('create index if not exists promociones_activo_idx on promociones (activo)');
    }

    public function down(): void
    {
        Schema::dropIfExists('promociones');
    }
};
