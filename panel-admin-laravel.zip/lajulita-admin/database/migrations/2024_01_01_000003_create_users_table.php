<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('users')) {
            Schema::create('users', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('email')->unique();
                $table->timestamp('email_verified_at')->nullable();
                $table->string('password');
                // Un solo rol por usuario alcanza para el tamaño de este equipo (administrador /
                // vendedor). nullOnDelete: si se borra un rol, el usuario queda sin rol (sin
                // permisos) en vez de romperse — mejor eso que perder la cuenta.
                $table->foreignId('rol_id')->nullable()->constrained('roles')->nullOnDelete();
                // Para poder "inhabilitar" un usuario (ej. un vendedor que ya no trabaja acá)
                // sin borrar su historial en la bitácora.
                $table->boolean('activo')->default(true);
                $table->rememberToken();
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('password_reset_tokens')) {
            Schema::create('password_reset_tokens', function (Blueprint $table) {
                $table->string('email')->primary();
                $table->string('token');
                $table->timestamp('created_at')->nullable();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('password_reset_tokens');
    }
};
