<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tablas ya existentes en el Supabase real del bot (ver sql/schema.sql en el repo del bot).
 * Esta migración es solo de RESPALDO: si el panel se instala apuntando a un Supabase nuevo
 * (sin las tablas del bot todavía), las crea idénticas; si ya existen (el caso normal), no
 * toca nada gracias al `hasTable`.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('clase_domo')) {
            return;
        }

        Schema::create('clase_domo', function (Blueprint $table) {
            $table->id();
            $table->string('nombre')->unique();
        });
    }

    public function down(): void
    {
        // A propósito no se borra: es una tabla del bot, no de este panel.
    }
};
