<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('faq')) {
            return;
        }

        Schema::create('faq', function (Blueprint $table) {
            $table->text('tema')->primary();
            $table->text('pregunta_ejemplo')->nullable();
            $table->text('respuesta');
            $table->timestamp('updated_at')->useCurrent();
        });
    }

    public function down(): void
    {
        //
    }
};
