<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('planes')) {
            return;
        }

        Schema::create('planes', function (Blueprint $table) {
            $table->id();
            $table->text('nombre');
            $table->text('descripcion')->nullable();
            $table->decimal('precio_entre_semana', 12, 2)->nullable();
            $table->decimal('precio_fin_de_semana', 12, 2)->nullable();
            $table->decimal('precio_fin_de_semana_puente', 12, 2)->nullable();
            $table->text('link_video')->nullable();
            $table->boolean('activo')->default(true);
        });

        // domos_id (int[]) no se puede declarar con el Schema builder de Laravel -> se agrega
        // con SQL crudo, igual que en sql/schema.sql del bot.
        DB::statement('alter table planes add column if not exists domos_id int[]');
        DB::statement('create index if not exists planes_domos_id_idx on planes using gin (domos_id)');
    }

    public function down(): void
    {
        //
    }
};
