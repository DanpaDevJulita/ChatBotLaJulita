<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('fechas_bloqueadas')) {
            return;
        }

        DB::statement('create extension if not exists "pgcrypto"');

        Schema::create('fechas_bloqueadas', function (Blueprint $table) {
            $table->uuid('id')->default(DB::raw('gen_random_uuid()'))->primary();
            $table->date('fecha')->unique();
            $table->text('motivo')->nullable();
        });
    }

    public function down(): void
    {
        //
    }
};
