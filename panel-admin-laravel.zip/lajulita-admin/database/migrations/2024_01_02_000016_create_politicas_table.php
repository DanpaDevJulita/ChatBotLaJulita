<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('politicas')) {
            return;
        }

        Schema::create('politicas', function (Blueprint $table) {
            $table->string('clave')->primary();
            $table->text('titulo')->nullable();
            $table->text('contenido');
            $table->boolean('activo')->default(true);
            $table->timestamp('updated_at')->useCurrent();
        });
    }

    public function down(): void
    {
        //
    }
};
