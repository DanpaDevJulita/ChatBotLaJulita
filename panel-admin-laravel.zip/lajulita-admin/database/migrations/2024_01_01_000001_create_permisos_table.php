<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('permisos')) {
            return;
        }

        Schema::create('permisos', function (Blueprint $table) {
            $table->id();
            // Ej: "planes.editar". Se checa en código (middleware permiso:planes.editar).
            $table->string('clave')->unique();
            // Ej: "planes" — para agrupar en la pantalla de Roles.
            $table->string('modulo');
            // Ej: "Editar planes" — lo que ve el usuario en el checklist de permisos.
            $table->string('etiqueta');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('permisos');
    }
};
