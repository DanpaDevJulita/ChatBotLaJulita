<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('recargos')) {
            return;
        }

        Schema::create('recargos', function (Blueprint $table) {
            $table->id();
            $table->string('tipo'); // 'nino' | 'mascota'
            $table->text('nombre');
            $table->text('descripcion')->nullable();
            $table->decimal('precio', 12, 2);
            $table->integer('edad_min')->nullable();
            $table->integer('edad_max')->nullable();
            $table->foreignId('plan_id')->nullable()->constrained('planes')->cascadeOnDelete();
            $table->boolean('activo')->default(true);
            $table->timestamp('updated_at')->useCurrent();
        });

        DB::statement("alter table recargos add constraint recargos_tipo_check check (tipo in ('nino','mascota'))");
        DB::statement('create index if not exists recargos_tipo_activo_idx on recargos (tipo, activo)');
    }

    public function down(): void
    {
        //
    }
};
