<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Ver App\Support\RegistradorBitacora: quién cambió qué desde el panel, y cuándo. */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('bitacora_cambios')) {
            return;
        }

        Schema::create('bitacora_cambios', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('modulo'); // ej. "planes"
            $table->string('accion'); // ej. "crear" | "editar" | "eliminar" | "activar" | "inhabilitar"
            $table->text('descripcion');
            $table->jsonb('datos_anteriores')->nullable();
            $table->jsonb('datos_nuevos')->nullable();
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('bitacora_cambios');
    }
};
