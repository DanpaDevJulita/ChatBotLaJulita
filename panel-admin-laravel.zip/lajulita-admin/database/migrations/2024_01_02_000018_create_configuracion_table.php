<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('configuracion')) {
            return;
        }

        Schema::create('configuracion', function (Blueprint $table) {
            $table->string('clave')->primary();
            $table->text('valor');
            $table->timestamp('updated_at')->useCurrent();
        });
    }

    public function down(): void
    {
        //
    }
};
