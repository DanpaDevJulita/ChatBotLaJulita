<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('domos')) {
            return;
        }

        Schema::create('domos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('clase')->constrained('clase_domo');
            $table->text('opcion')->nullable();
            $table->integer('capacidad_max');
        });
    }

    public function down(): void
    {
        //
    }
};
