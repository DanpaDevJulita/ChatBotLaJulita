<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('adicionales')) {
            return;
        }

        Schema::create('adicionales', function (Blueprint $table) {
            $table->id();
            $table->text('nombre');
            $table->text('descripcion')->nullable();
            $table->decimal('precio', 12, 2)->nullable();
            $table->foreignId('tipo_adicional_id')->constrained('tipo_adicional');
            $table->boolean('estado')->default(true);
        });
    }

    public function down(): void
    {
        //
    }
};
