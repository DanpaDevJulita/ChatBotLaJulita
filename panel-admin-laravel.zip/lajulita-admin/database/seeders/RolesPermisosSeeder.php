<?php

namespace Database\Seeders;

use App\Models\Permiso;
use App\Models\Rol;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

/**
 * Crea los permisos de cada módulo, dos roles por defecto (Administrador / Vendedor) y un
 * primer usuario administrador para poder entrar la primera vez. Se puede correr varias veces
 * sin duplicar nada (todo usa updateOrCreate / firstOrCreate).
 */
class RolesPermisosSeeder extends Seeder
{
    /** Módulos administrables y su etiqueta bonita para la pantalla de Roles. */
    private const MODULOS = [
        'planes' => 'Planes',
        'domos' => 'Domos y clases de domo',
        'adicionales' => 'Adicionales',
        'recargos' => 'Niños y mascotas',
        'promociones' => 'Promociones',
        'politicas' => 'Políticas',
        'faq' => 'Preguntas frecuentes',
        'configuracion' => 'Horarios y fechas bloqueadas',
        'usuarios' => 'Usuarios',
        'roles' => 'Roles y permisos',
    ];

    /** Acciones por módulo y cómo se ve cada una en el checklist de permisos. */
    private const ACCIONES = [
        'ver' => 'Ver',
        'crear' => 'Crear',
        'editar' => 'Editar',
        'eliminar' => 'Eliminar',
    ];

    /**
     * Módulos donde el rol Vendedor puede trabajar (ver/crear/editar, nunca eliminar): son el
     * contenido comercial del día a día. Domos, configuración, usuarios y roles quedan solo
     * para Administrador porque son más estructurales o sensibles.
     */
    private const MODULOS_VENDEDOR = ['planes', 'adicionales', 'recargos', 'promociones', 'politicas', 'faq'];

    public function run(): void
    {
        $todosLosPermisos = [];

        foreach (self::MODULOS as $modulo => $etiquetaModulo) {
            foreach (self::ACCIONES as $accion => $etiquetaAccion) {
                $permiso = Permiso::updateOrCreate(
                    ['clave' => "{$modulo}.{$accion}"],
                    ['modulo' => $modulo, 'etiqueta' => "{$etiquetaAccion} — {$etiquetaModulo}"]
                );
                $todosLosPermisos[] = $permiso;
            }
        }

        $administrador = Rol::updateOrCreate(
            ['nombre' => 'Administrador'],
            ['descripcion' => 'Acceso total: catálogo, configuración, usuarios y roles.']
        );
        $administrador->permisos()->sync(collect($todosLosPermisos)->pluck('id'));

        $vendedor = Rol::updateOrCreate(
            ['nombre' => 'Vendedor'],
            ['descripcion' => 'Puede actualizar planes, adicionales, recargos, promociones, políticas y FAQ (sin eliminar).']
        );
        $permisosVendedor = collect($todosLosPermisos)
            ->filter(fn (Permiso $p) => in_array($p->modulo, self::MODULOS_VENDEDOR) && $p->clave !== "{$p->modulo}.eliminar")
            ->pluck('id');
        $vendedor->permisos()->sync($permisosVendedor);

        // Primer usuario administrador, solo si todavía no hay ninguno con este correo.
        $correo = 'daniel.pataquiva@lajulitadevelopment.site';
        if (! User::where('email', $correo)->exists()) {
            $claveInicial = env('ADMIN_PASSWORD_INICIAL', 'CambiaEstaClave123');

            User::create([
                'name' => 'Daniel Pataquiva',
                'email' => $correo,
                'password' => Hash::make($claveInicial),
                'rol_id' => $administrador->id,
                'activo' => true,
            ]);

            $this->command?->warn(
                "Usuario administrador creado: {$correo} / contraseña: {$claveInicial}".
                ' — cámbiala apenas entres (menú Usuarios).'
            );
        }
    }
}
